//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter04Page05Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, dcMotor(power1:power2:), wait(duration:), stop())
//#-code-completion(identifier, show, getKnob(), getLight(), getDistance(), hasObstacle(), playSound(note:beat:), ledColor(color:), ledColor(color:style:), ledColors(colors:), ledColors(colors:style:), closeLed(), panelShow(expression:), panelClear(), iPadTiltedForward(), iPadTiltedBackward(), iPadTiltedLeft(), iPadTiltedRight(), iPadSound(note:), stopiPadSound())
//#-code-completion(identifier, show, PadSoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundBeat, whole, half, quarter, eighth, sixteenth)
//#-code-completion(identifier, show, Expression, angry, smile, smiley, happy, shock, sun, moon, fire, blank, forward, backward, left, right)
//#-code-completion(keyword, show, for, func, if, var, while)
DispatchQueue.global().async {
var time = 0;
//#-end-hidden-code
while true {
    //#-editable-code Tap to enter code
    let distance = getDistance()
    if 3 <= distance && distance <= 4 {
        iPadSound(note: .c5)
    } else if 5 <= distance && distance <= 6 {
        iPadSound(note: .b4)
    } else if 8 <= distance && distance <= 10 {
        iPadSound(note: .a4)
    } else if 11 <= distance && distance <= 13 {
        iPadSound(note: .g4)
    } else if 14 <= distance && distance <= 16 {
        iPadSound(note: .f4)
    } else if 18 <= distance && distance <= 20 {
        iPadSound(note: .e4)
    } else if 22 <= distance && distance <= 23 {
        iPadSound(note: .d4)
    } else if 26 <= distance && distance <= 28 {
        iPadSound(note: .c4)
    }
    //#-end-editable-code
    //#-hidden-code
    if time < 1 {
        RuleManager.shared.check()
    }
    time += 1
    //#-end-hidden-code
}
//#-hidden-code
}
RuleManager.shared.check()
//#-end-hidden-code
