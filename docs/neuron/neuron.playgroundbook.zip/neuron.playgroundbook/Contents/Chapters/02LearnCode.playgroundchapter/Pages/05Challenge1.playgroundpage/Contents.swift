//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter02Page05Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, dcMotor(power1:power2:), wait(duration:), stop())
//#-editable-code Tap to enter code
//#-editable-code Tap to enter code
//#-end-editable-code
stop()
//#-end-editable-code
//#-hidden-code
RuleManager.shared.check()
//#-end-hidden-code
