//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter02Page06Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, LEDColor, black, red, orange, yellow, green, cyan, blue, purple, white)
//#-code-completion(identifier, show, LEDStyle, light, marquee, breathing)
//#-editable-code Tap to enter code
dcMotor(power1: 90, power2: 90)
ledColor(color: <#T##color##LEDColor#>, style: <#T##style##LEDStyle#>)
wait(duration: 3.0)
closeLed()
stop()
//#-end-editable-code
//#-hidden-code
RuleManager.shared.check()
//#-end-hidden-code
