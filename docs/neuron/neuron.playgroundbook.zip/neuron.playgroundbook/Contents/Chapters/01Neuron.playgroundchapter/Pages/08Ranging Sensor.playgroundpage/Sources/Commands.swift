//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func getDistance() -> Int {
    wait(duration: 0.1)
    ActionTool.getDistance()
    return contentListenr.getDistance
}

public func flyingHeight(_ heihgt: Int) {
    ActionTool.distance(heihgt)
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}

