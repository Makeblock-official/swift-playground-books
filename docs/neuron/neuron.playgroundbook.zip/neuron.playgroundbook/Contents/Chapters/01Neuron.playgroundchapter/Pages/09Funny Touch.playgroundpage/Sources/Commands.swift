//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func getBlueTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    
    let t1=CACurrentMediaTime()
    while !contentListenr.blueTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.blueTouched
}

public func getYellowTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    
    let t1=CACurrentMediaTime()
    while !contentListenr.blueTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.yellowTouched
}

public func getRedTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    
    let t1=CACurrentMediaTime()
    while !contentListenr.blueTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.redTouched
}

public func getGreenTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    
    let t1=CACurrentMediaTime()
    while !contentListenr.blueTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.greenTouched
}

public func blueHammer() {
    ActionTool.hammer(1)
}

public func yellowHammer() {
    ActionTool.hammer(2)
}

public func redHammer() {
    ActionTool.hammer(3)
}

public func greenHammer() {
    ActionTool.hammer(4)
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
