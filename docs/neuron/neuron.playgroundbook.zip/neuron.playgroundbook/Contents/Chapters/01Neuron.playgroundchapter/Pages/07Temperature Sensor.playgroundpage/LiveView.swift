//
//  LiveView.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

//#-hidden-code
playgroundPrologue()
setTemperatureScene(chapter: 0, page: 7)
//#-end-hidden-code
