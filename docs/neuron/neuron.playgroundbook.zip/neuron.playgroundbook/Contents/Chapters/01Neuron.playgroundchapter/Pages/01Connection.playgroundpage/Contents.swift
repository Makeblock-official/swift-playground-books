//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter01Page01Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, playSound(note:beat:))
//#-code-completion(identifier, show, SoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundBeat, whole, half, quarter, eighth, sixteenth)
//#-code-completion(keyword, show, for, func, if, var, while)
//#-editable-code Tap to enter code
playSound(note:.c4,beat:.half)
playSound(note:.c4,beat:.half)
playSound(note:.g4,beat:.half)
playSound(note:.g4,beat:.half)
playSound(note:.a4,beat:.half)
playSound(note:.a4,beat:.half)
playSound(note:.g4,beat:.whole)
playSound(note:.f4,beat:.half)
playSound(note:.f4,beat:.half)
playSound(note:.e4,beat:.half)
playSound(note:.e4,beat:.half)
playSound(note:.d4,beat:.half)
playSound(note:.d4,beat:.half)
playSound(note:.c4,beat:.whole)

//#-end-editable-code
//#-hidden-code
RuleManager.shared.check()
//#-end-hidden-code
