//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func djMusic(_ note: Int) {
    ActionTool.iPadmusic(note)
}

public func getKnob() -> Int {
    wait(duration: 0.1)
    ActionTool.getKnob()
    
    
    let t1=CACurrentMediaTime()
    while contentListenr.getKnob == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getKnob
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
