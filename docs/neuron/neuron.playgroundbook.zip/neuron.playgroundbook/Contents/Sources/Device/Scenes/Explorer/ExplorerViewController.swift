//
//  ExplorerViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/7.
//  Copyright © 2018年 makeblock. All rights reserved.
//

import UIKit

public class ExplorerViewController: NeuronViewController {
    public let stageView = ExplorerStageView(frame: CGRect.zero)
    private var tiltDetector = TiltDetector()

    override public func viewDidLoad() {
        super.viewDidLoad()
        setupStageView()
        tiltDetector.delegate = self
    }

    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tiltDetector.start()
    }

    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tiltDetector.stop()
    }

    override public func onStopRunning() {
        currentBot.setBothDCMotor(speed1: 0, speed2: 0)
    }

    public override func didPrepared() {
        currentBot.setBothDCMotor(speed1: 0, speed2: 0)
    }
    
    public override func didConnect() {
        stageView.openCurtain()
    }
    
    public override func didDisconnect() {
        stageView.closeCurtain()
    }

    public func setDistance(enable: Bool) {
        stageView.setDistance(enable: enable)
    }

    public func setLight(enable: Bool) {
        stageView.setLight(enable: enable)
    }

    public func setSound(enable: Bool) {
        stageView.setSound(enable: enable)
    }

    public func setSpeed1(_ speed: Int) {
        stageView.setSpeed1(speed)
    }

    public func setSpeed2(_ speed: Int) {
        stageView.setSpeed2(speed)
    }

    public func showExpression(_ type: Expression) {
        stageView.showExpression(type)
    }

    func setupStageView() {
        view.addSubview(stageView)
        stageView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }
}

extension ExplorerViewController: TiltDetectorDelegate {
    public func onTiltUpdate(left: Bool, right: Bool, forword: Bool, backword: Bool) {
        sendToContentsWithEnum(.iPadTiltedForward(forword))
        sendToContentsWithEnum(.iPadTiltedBackward(backword))
        sendToContentsWithEnum(.iPadTiltedLeft(left))
        sendToContentsWithEnum(.iPadTiltedRight(right))
    }
}
