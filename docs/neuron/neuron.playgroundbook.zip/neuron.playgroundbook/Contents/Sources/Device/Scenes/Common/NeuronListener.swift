import UIKit

public class NeuronListener: BlockContainerDelegate, NeuronPackageInterpreterDelegate {
    public var isBuzzerConnected = false

    public func onReceive(gyroSensorPackage: GyroSensorPackage) {
        switch gyroSensorPackage.dataType {
        case .xAngle:
            sendToContentsWithEnum(.gyroXangle(gyroSensorPackage.value))
        case .yAngle:
            sendToContentsWithEnum(.gyroYangle(gyroSensorPackage.value))
        case .zAngle:
            sendToContentsWithEnum(.gyroZangle(gyroSensorPackage.value))
        default:
            break
        }
    }

    public func onReceive(funnyTouchPackage: FunnyTouchPackage) {
        sendToContentsWithEnum(.blueTouched(funnyTouchPackage.blueTouched))
        sendToContentsWithEnum(.greenTouched(funnyTouchPackage.greenTouched))
        sendToContentsWithEnum(.redTouched(funnyTouchPackage.redTouched))
        sendToContentsWithEnum(.yellowTouched(funnyTouchPackage.yellowTouched))
    }

    public func onReceive(knobPackage: KnobPackage) {
        sendToContentsWithEnum(.getKnob(knobPackage.value))
    }

    public func onReceive(temperaturePackage: TemperaturePackage) {
        sendToContentsWithEnum(.getTemperature(temperaturePackage.value))
    }

    public func onReceive(lightPackage: LightPackage) {
        sendToContentsWithEnum(.getLight(lightPackage.value))
    }

    public func onReceive(distancePackage: DistancePackage) {
        sendToContentsWithEnum(.getDistance(distancePackage.value))
        currentPianoViewController?.stageView.setRanger(value: distancePackage.value)
    }

    public func onReceive(voicePackage: VoicePackage) {
        sendToContentsWithEnum(.getVoice(voicePackage.value))
    }

    public func onReceive(soilMoisturePackage: SoilMoisturePackage) {
        sendToContentsWithEnum(.getSoilmoisture(soilMoisturePackage.value))
    }

    public func onReceive(unkonwnPackage: Data) {
    }

    public func didConnect(block: BlockType, on position: Int) {
        switch block {
        case .light:
            currentBot.getLight()
            guard let vc = currentKnowNeuronViewController,
                vc.chapter == 0,
                vc.page == 6 else {
                    return
            }
            vc.stageView.showDefaultLightSensor()
            
        case .distance:
            currentBot.getDistance()
            guard let vc = currentKnowNeuronViewController,
                vc.chapter == 0,
                vc.page == 8 else {
                    return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                vc.stageView.showPlane(true)
            }
            vc.stageView.playGIF(.distanceStageOpen, loopCount: 1)
            
        case .gyro:
            currentBot.subscribeGyroData(dataType: .xAngle, way: .onChange, timeIntervalInMs: 500)
            currentBot.subscribeGyroData(dataType: .yAngle, way: .onChange, timeIntervalInMs: 500)
            currentBot.subscribeGyroData(dataType: .zAngle, way: .onChange, timeIntervalInMs: 500)
            
        case .temperature:
            currentBot.getTemperature()
            currentTemperatureViewController?.stageView.showTemperature()
            
        case .funnyTouch:
            currentBot.getFunnyTouch()
            
        case .knob:
            currentBot.getKnob()
            guard let vc = currentKnobViewController,
                vc.chapter == 0,
                vc.page == 5 else {
                    return
            }
            vc.stageView.showKnob()
            
        case .led:
            guard let vc = currentKnowNeuronViewController else {
                return
            }
            let stageView = vc.stageView

            if vc.chapter == 0 {
                switch vc.page {
                case 4:
                    stageView.showExpression(.blank)
                default:
                    break
                }
            }
        case .ledBand:
            guard let vc = currentKnowNeuronViewController else {
                return
            }
            let stageView = vc.stageView

            if vc.chapter == 0 {
                switch vc.page {
                case 3:
                    stageView.moveLight(down: true)
                case 4, 5:
                    stageView.moveLight(down: true)
                default:
                    break
                }
            }
        case .buzzer:
            isBuzzerConnected = true

            guard let vc = currentKnowNeuronViewController else {
                return
            }
            let stageView = vc.stageView

            if vc.chapter == 0 {
                switch vc.page {
                case 1, 2, 3:
                    stageView.playGIF(.hello, loopCount: 1)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        stageView.stopGIF()
                    }
                default:
                    break
                }
            }
        default:
            break
        }
    }

    public func didDisConnect(block: BlockType, on position: Int) {
        switch block {
        case .light:
            guard let vc = currentKnowNeuronViewController,
                vc.chapter == 0 else {
                    return
            }
            if vc.page == 1 {
                vc.stageView.showDefaultStage()
            } else if vc.page == 6 {
                vc.stageView.hideDefaultLightSensor()
            }
            
        case .distance:
            guard let vc = currentKnowNeuronViewController,
                vc.chapter == 0,
                vc.page == 8 else {
                    return
            }
            vc.stageView.showDefaultStage()
            sendToContentsWithEnum(.getDistance(-99))
            
        case .led:
            guard let vc = currentKnowNeuronViewController,
                vc.chapter == 0,
                vc.page == 4 else {
                    return
            }
            vc.stageView.hideExpression()
            
        case .ledBand:
            guard let vc = currentKnowNeuronViewController else {
                return
            }
            vc.stageView.moveLight(down: false)
            vc.stageView.turnSpot(isOpen: false)
            
        case .buzzer:
            isBuzzerConnected = false
            guard let vc = currentKnowNeuronViewController,
                vc.chapter == 0,
                vc.page == 1 || vc.page == 2 || vc.page == 3 else {
                    return
            }
            vc.stageView.playGIF(.goodbye, loopCount: 1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                vc.stageView.hideCharacter()
            }
            
        case .knob:
            guard let vc = currentKnobViewController,
                vc.chapter == 0,
                vc.page == 5 else {
                    return
            }
            vc.stageView.hideKnob()
            
        case .temperature:
            currentTemperatureViewController?.stageView.hideTemperature()
            
        default:
            break
        }
    }
}
