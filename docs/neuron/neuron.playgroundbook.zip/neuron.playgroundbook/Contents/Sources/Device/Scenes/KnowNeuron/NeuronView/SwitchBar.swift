//
//  SwitchBar.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/17.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit

class SwitchBar: UIView {
    public var font: UIFont = UIFont.systemFont(ofSize: 14)
    public var textOne: String = ""
    public var textTwo: String = ""
    lazy public var selectedTextColor: UIColor = {
        return UIColor.white
    }()
    lazy public var normalTextColor: UIColor = {
        return color(20, 136, 251)
    }()

    lazy public var backColor: UIColor = {
        return color(20, 136, 251)
    }()

    public var didSelectAction: ((Int) -> Void)?

    public var backView: UIView = UIView()
    public var firstLabel: UIButton = UIButton.init(type: .custom)
    public var secLabel: UIButton = UIButton.init(type: .custom)

    private var height: CGFloat = 40
    init(textOne: String, textTwo: String, originPoint: CGPoint) {
        super.init(frame: CGRect.init(origin: originPoint, size: CGSize.zero))
        self.addSubview(backView)
        self.addSubview(firstLabel)
        self.addSubview(secLabel)
        self.textOne = textOne
        self.textTwo = textTwo
        self.originConfig()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        configSwitchFrame()
    }

    private func originConfig() {
        backgroundColor = UIColor.white
        firstLabel.setTitle(textOne, for: .normal)
        firstLabel.setTitleColor(selectedTextColor, for: .normal)
        firstLabel.tag = 0
        secLabel.setTitle(textTwo, for: .normal)
        secLabel.setTitleColor(normalTextColor, for: .normal)
        secLabel.tag = 1
        backView.backgroundColor = backColor

        firstLabel.addTarget(self, action: #selector(buttonTapped(sender:)), for: .touchUpInside)
        secLabel.addTarget(self, action: #selector(buttonTapped(sender:)), for: .touchUpInside)
    }

    // MARK: Action

    @objc func buttonTapped(sender: UIButton) {
        if let action = didSelectAction {
            action(sender.tag)
        }
        setSelected(sender.tag)
    }

    // MARK: Private

    private func setSelected(_ index: Int) {
        let labelWidth = backView.bounds.width
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseInOut, animations: {
            self.backView.frame = CGRect.init(x: CGFloat(index) * labelWidth, y: 0, width: labelWidth, height: self.backView.bounds.height)
            if index == 0 {
                self.firstLabel.setTitleColor(self.selectedTextColor, for: .normal)
                self.secLabel.setTitleColor(self.normalTextColor, for: .normal)
            } else {
                self.firstLabel.setTitleColor(self.normalTextColor, for: .normal)
                self.secLabel.setTitleColor(self.selectedTextColor, for: .normal)
            }
        }, completion: nil)
    }

    private func configSwitchFrame() {
        var frameTmp = frame
        let firstWidth = NSString.init(string: textOne).boundingRect(with: CGSize.init(width: 1000, height: height), options: .usesLineFragmentOrigin, attributes: nil, context: nil).width
        let secWidth = NSString.init(string: textOne).boundingRect(with: CGSize.init(width: 1000, height: height), options: .usesLineFragmentOrigin, attributes: nil, context: nil).width
        let width = max(firstWidth, secWidth)
        let labelWidth = width + 20
        _ = labelWidth * 2
        frameTmp.size = CGSize.init(width: 160, height: height)
        frame = frameTmp
        layer.masksToBounds = true
        layer.cornerRadius = height / 2

        configLableFrame(width: 80, height: height)
        configBackFrame(width: 80, height: height)
    }

    private func configLableFrame(width: CGFloat, height: CGFloat) {
        firstLabel.frame = CGRect.init(x: 0, y: 0, width: width, height: height)
        secLabel.frame = CGRect.init(x: width, y: 0, width: width, height: height)
    }

    private func configBackFrame(width: CGFloat, height: CGFloat) {
        backView.frame = CGRect.init(x: 0, y: 0, width: width, height: height)
        backView.layer.masksToBounds = true
        backView.layer.cornerRadius = height / 2
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
