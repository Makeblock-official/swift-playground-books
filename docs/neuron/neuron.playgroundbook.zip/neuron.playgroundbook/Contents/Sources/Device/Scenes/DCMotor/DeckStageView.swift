//
//  DeckStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/7.
//  Copyright © 2018年 makeblock. All rights reserved.
//

import UIKit

public class DeckStageView: UIView {
    fileprivate let bgView = UIImageView(frame: CGRect.zero)
    fileprivate let curtainGifView = UIImageView(frame: .zero)
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)

    override public init(frame: CGRect) {
        super.init(frame: frame)
        clipsToBounds = true

        setupBg()
        setupGameView()
        setupCurtain()
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: Public

    public func setBgImage(_ image: UIImage?) {
        bgView.image = image
    }

    public func openCurtain() {
        curtainGifView.setGifImage(UIImage(gifName: "deck_bg"),
                                   manager: gifManager,
                                   loopCount: 1)
        curtainGifView.startAnimatingGif()
    }
    
    public func closeCurtain() {
        curtainGifView.gifImage = UIImage(gifName: "deck_bg")
        curtainGifView.showFrameAtIndex(0)
        curtainGifView.image = curtainGifView.currentImage
    }

    // Overrided by subclass

    public func setupGameView() {
    }

    // MARK: Private

    private func setupBg() {
        bgView.contentMode = .scaleAspectFill
        bgView.clipsToBounds = true
        addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
    }

    private func setupCurtain() {
        curtainGifView.contentMode = .scaleAspectFill
        addSubview(curtainGifView)
        curtainGifView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        closeCurtain()
    }
}
