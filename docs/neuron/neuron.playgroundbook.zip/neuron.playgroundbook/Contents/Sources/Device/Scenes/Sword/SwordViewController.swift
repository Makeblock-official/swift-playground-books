//
//  Sword.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/21.
//

import UIKit

public class SwordViewController: NeuronViewController {
    public let stageView = SwordStageView(frame: CGRect.zero)

    override public func viewDidLoad() {
        super.viewDidLoad()
        setupStageView()
    }

    override public func onStopRunning() {
        currentBot.setBothDCMotor(speed1: 0, speed2: 0)
    }
    
    public override func didConnect() {
        stageView.openCurtain()
    }
    
    public override func didDisconnect() {
        stageView.closeCurtain()
    }

    func setupStageView() {
        view.addSubview(stageView)
        stageView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }
}
