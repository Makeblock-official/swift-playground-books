//
//  ChartsCell.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/23.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit

class ChartsCell: UITableViewCell {

    var valueLabel: UILabel!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        valueLabel = UILabel()
        selectionStyle = .none
        backgroundColor = UIColor.clear
        contentView.addSubview(valueLabel)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    public var model: ChartCellModel = ChartCellModel() {
        didSet {
            valueLabel.text = model.name + ": " + model.value
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        valueLabel.frame = contentView.bounds.insetBy(dx: 25, dy: 0)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = UIColor.clear
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
