//
//  TaskResponder.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import CoreBluetooth

public protocol TaskResponder {
    associatedtype Command: SPCommand
    var command: Command {get set}
    func respondTo(_ command: Command)
    func stop()
    init(command: Command)
}

extension TaskResponder {
    func execeute(finished: ((Bool) -> Void)) {
        respondTo(command)
        finished(true)
    }
}

public class BLETaskResponder: TaskResponder {

    public typealias Command = MessageCommand
    public var command: Command

    private var currentLightIntensity: Float = -1
    private var isPlayingBackLoop = false

    required public init(command: Command) {
        self.command = command
    }

    private var timers: [Timer] = []
    public func respondTo(_ command: MessageCommand) {
        switch command.action {
        case .sound(let note, let beat):
            playSound(note, beat)
        case .dcMotor(let slot, let power):
            dcMotor(slot, power)
        case .dcMotorMeanwhile(let power1, let power2):
            dcMotorMeanwhile(power1, power2)
        case .servo(let port, let angle):
            turnServo(port, angle)
        case .led(let x, let y, let r, let g, let b):
            turnLED(x, y, r, g, b)
        case .ledBand(let color, let style):
            ledBand(color, style)
        case .ledBandColors(let colors, let style):
            ledBand(colors: colors, style: style)
        case .ledPanel(let expression):
            ledPanel(expression)
        case .panelColor(let r, let g, let b):
            panelColor(r, g, b)
        case .getKnob:
            getKnob()
        case .getLight:
            getLight()
        case .getTemperature:
            getTemperature()
        case .getFunnyTouch:
            getFunnyTouch()
        case .getDistance:
            getDistance()
        case .powerOn:
            powerOn()
        case .powerOff:
            powerOff()
        case .wait(let duration):
            wait(duration)
        case .lightSensor(let lightIntensity):
            changeLightIntensity(lightIntensity)
        case .distanceSensor(let distance):
            changeDistance(distance)
        case .testText(let text):
            log(text)
        case .iPadmusic(let note):
            iPadmusic(note)
        case .thermometer(let temperature):
            thermometer(temperature)
        case .hammer(let color):
            hammer(color)
        case .getBuzzerConnectState:
            getBuzzerConnectState()
        case .iPadSound(let note):
            iPadSound(note: note)
        case .stopiPadSound:
            stopiPadSound()
        default:
            print("Default Action")
        }
    }

    private func wait(_ duration: Float) {
    }

    private func changeDistance(_ distance: Int) {
        if distance > 0 {
            Loader.currentKnowNeuronViewController?.stageView.animatePlane(percent: CGFloat(CGFloat(distance) / 15))
            if isPlayingBackLoop == false {
                Loader.currentKnowNeuronViewController?.stageView.playGIF(.distanceFlyBack, loopCount: -1)
                isPlayingBackLoop = true
            }
        } else {
            isPlayingBackLoop = false
        }
    }

    private func changeLightIntensity(_ lightIntensity: Float) {
        if lightIntensity > 15 {
            if currentLightIntensity <= 15 && currentLightIntensity != -1 {
                Loader.currentKnowNeuronViewController?.stageView.playGIF(.lightGetBright, loopCount: 1)
            }
        } else {
            if currentLightIntensity > 15 || currentLightIntensity == -1 {
                Loader.currentKnowNeuronViewController?.stageView.playGIF(.lightGetDark, loopCount: 1)
            }
        }
        currentLightIntensity = lightIntensity
    }

    private func startHeartbeat() {
        Loader.currentBot.startHeartbeat()
    }

    private func stopHeartbeat() {
        Loader.currentBot.stopHeartbeat()
    }

    private func subscribeForGyroData() {
        Loader.currentBot.subscribeGyroData(dataType: .xAngle, way: .cyclicity, timeIntervalInMs: 500)
        Loader.currentBot.subscribeGyroData(dataType: .yAngle, way: .cyclicity, timeIntervalInMs: 500)
        Loader.currentBot.subscribeGyroData(dataType: .zAngle, way: .cyclicity, timeIntervalInMs: 500)
    }

    private func cancelSubscribeForGyroData() {
        Loader.currentBot.cancelSubscribeGyroData(dataType: .xAngle)
        Loader.currentBot.cancelSubscribeGyroData(dataType: .yAngle)
        Loader.currentBot.cancelSubscribeGyroData(dataType: .zAngle)
    }

    private func getKnob() {
        Loader.currentBot.getKnob()
    }

    private func getLight() {
        Loader.currentBot.getLight()
        Loader.currentExplorerViewController?.setLight(enable: true)
    }

    private func getTemperature() {
        Loader.currentBot.getTemperature()
    }

    private func getDistance() {
        Loader.currentBot.getDistance()
        Loader.currentExplorerViewController?.setDistance(enable: true)
    }

    private func getFunnyTouch() {
        Loader.currentBot.getFunnyTouch()
    }

    private func powerOn() {
        startHeartbeat()
    }

    private func powerOff() {

    }

    private func playSound(_ note: SoundNote, _ beat: SoundBeat) {
        Loader.currentBot.setBuzzer(pitch: note, duration: beat)
        Loader.currentKnowNeuronViewController?.stageView.playGIF(.sing)
        Loader.currentExplorerViewController?.setSound(enable: true)
    }

    private func dcMotor(_ slot: DCMotorSlot, _ power: Int) {
        Loader.currentBot.setDCMotor(slot: slot, speed: power)

        switch slot {
        case .slot1:
            Loader.currentDCMotorViewController?.setSpeed1(power)
            Loader.currentExplorerViewController?.setSpeed1(power)
        case .slot2:
            Loader.currentDCMotorViewController?.setSpeed2(power)
            Loader.currentExplorerViewController?.setSpeed2(power)
        }
    }

    private func dcMotorMeanwhile(_ power1: Int, _ power2: Int) {
        Loader.currentBot.setBothDCMotor(speed1: power1, speed2: power2)

        Loader.currentDCMotorViewController?.setSpeed1(power1)
        Loader.currentDCMotorViewController?.setSpeed2(power2)

        Loader.currentExplorerViewController?.setSpeed1(power1)
        Loader.currentExplorerViewController?.setSpeed2(power2)
    }

    private func turnLED(_ x: Int, _ y: Int, _ r: Int, _ g: Int, _ b: Int) {
        Loader.currentBot.setRGBLED(x: x,
                                    y: y,
                                    red: r,
                                    green: g,
                                    blue: b)
    }

    private func ledBand(_ color: LEDColor, _ style: LEDStyle) {
        if style == .marquee {
            let colors = (0..<8).map {_ in color}
            Loader.currentBot.setLEDColors(colors, animateMode: .marquee, animateSpeed: 5)
        } else {
            Loader.currentBot.setLEDColor(color, animateMode: style)
        }

        Loader.currentKnowNeuronViewController?.stageView.turnSpot(isOpen: true, color: color)
    }
    
    private func ledBand(colors: [LEDColor], style: LEDStyle) {
        Loader.currentBot.setLEDColors(colors, animateMode: style, animateSpeed: 0)
    }

    private func ledPanel(_ expression: Expression) {
        Loader.currentBot.setLEDMatrix(colors: expression.colors)
        Loader.currentKnowNeuronViewController?.stageView.showExpression(expression)
        Loader.currentExplorerViewController?.showExpression(expression)
    }

    private func panelColor(_ r: Int, _ g: Int, _ b: Int) {
        Loader.currentBot.setRGBLED(x: 0,
                                    y: 0,
                                    red: r,
                                    green: g,
                                    blue: b)
    }

    private func turnServo(_ port: ServoPort, _ angle: Int) {
        Loader.currentBot.setServo(port: port, angle: angle)
    }

    public func stop() {
        let delayTime: DispatchTime = DispatchTime.now() + DispatchTimeInterval.milliseconds(2)
        DispatchQueue.main.asyncAfter(deadline: delayTime) {
        }
    }

    public func stopAll() {
        timers.forEach { timer in
                timer.invalidate()
        }
        timers.removeAll()
        stop()
    }

    private func iPadmusic(_ note: Int) {
        Loader.currentKnobViewController?.iPadmusic(note: note)
    }

    private func thermometer(_ temperature: Int) {
        Loader.currentTemperatureViewController?.thermometer(temperature: temperature)
    }

    private func hammer(_ color: Int) {
        Loader.currentFunnyTouchViewController?.hammer(color: color)
    }

    private func getBuzzerConnectState() {
        let isBuzzerConnected = Loader.currentLiveViewController?.neuronListener.isBuzzerConnected
        if let isBuzzerConnected = isBuzzerConnected {
            sendToContentsWithEnum(.isBuzzerConnected(isBuzzerConnected))
        } else {
            sendToContentsWithEnum(.isBuzzerConnected(false))
        }
    }
    
    private func iPadSound(note: PadSoundNote) {
        Loader.currentLiveViewController?.iPadSound(note: note)
    }
    
    private func stopiPadSound() {
        Loader.currentLiveViewController?.stopMusic()
    }
}
