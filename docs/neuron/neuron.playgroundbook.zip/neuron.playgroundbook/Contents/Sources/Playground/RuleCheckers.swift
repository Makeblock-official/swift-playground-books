//
//  RuleCheckers.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/7/11.
//

import PlaygroundSupport
import Foundation
import UIKit

public class EstablishConnectionChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter01Page01Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter01Page01Hint", comment: "")]

    public var solution: String?

    public func check(callback:@escaping ((Bool) -> Void)) {
        ActionTool.sendAction(SPCommandAction.getBuzzerConnectState)
        GCDDelay.delay(0.2) {
            let isContains = self.ruleTasks.contains(where: { (task) -> Bool in
                switch task {
                case RuleTask.connectBuzzer:
                    return true
                default:
                    return false
                }
            })
            callback(isContains)
        }
    }

    public init() {}
}

public class NormalRunningChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String

    public var hints: [String]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        callback(true)
    }

    public init(passMessage: String, hints: [String]) {
        self.passMessage = passMessage
        self.hints = hints
    }
}

public class BuzzerChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page02Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page02Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class LEDStripChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page03Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page03Hint", comment: ""),
                     NSLocalizedString("Chapter01Page03Hint2", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class LEDPanelChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page04Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page04Hint", comment: ""),
                     NSLocalizedString("Chapter01Page04Hint2", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class KnobChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page05Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page05Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class LightChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page06Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page06Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class TemperatureChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page07Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page07Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class RangingChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page08Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page08Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class FunnyTouchChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter01Page09Pass", comment: "")
        let hints = [NSLocalizedString("Chapter01Page09Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class ControlTheMotorChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter02Page01Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter02Page01Hint", comment: ""),
                                  NSLocalizedString("Chapter02Page01Hint2", comment: "")]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        var containMotorTask = false
        var isParamsVaild = true
        ruleTasks.forEach { (task) in
            switch task {
            case .dcMotor(let power1, let power2):
                containMotorTask = true
                if power1 < -100 || power1 > 100 || power2 < -100 || power2 > 100 {
                    isParamsVaild = false
                }
            default:
                break
            }
        }
        callback(containMotorTask && isParamsVaild)
    }

    public init() {}
}

public class StartTheExplorerChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter02Page03Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter02Page03Hint", comment: ""),
                                  NSLocalizedString("Chapter02Page03Hint2", comment: "")]

    public var solution: String? = NSLocalizedString("Chapter02Page03Solution", comment: "")

    public func check(callback: @escaping ((Bool) -> Void)) {
        var isParamsVaild = false
        ruleTasks.forEach { (task) in
            switch task {
            case .dcMotor(let power1, let power2):
                if power1 == 80 && power2 == -80 {
                    isParamsVaild = true
                }
            default:
                break
            }
        }
        callback(isParamsVaild)
    }

    public init() {}
}

public class DirectionControlChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter02Page04Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter02Page04Hint", comment: "")]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        var isParamsVaild = false
        ruleTasks.forEach { (task) in
            switch task {
            case .dcMotor(let power1, let power2):
                if (power1 == -50 && power2 == -50) ||  (power1 == 0 && power2 == -50) {
                    isParamsVaild = true
                }
            default:
                break
            }
        }
        callback(isParamsVaild)
    }

    public init() {}
}

public class Challenge1Checker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter02Page05Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter02Page05Hint", comment: ""),
                                  NSLocalizedString("Chapter02Page05Hint2", comment: "")]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        var containMotorTask = false
        var containWaitTask = false
        ruleTasks.forEach { (task) in
            switch task {
            case .dcMotor:
                containMotorTask = true
            case .wait:
                containWaitTask = true
            default:
                break
            }
        }
        callback(containMotorTask && containWaitTask)
    }

    public init() {}
}

public class TurnOnTheLightChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter02Page06Pass", comment: "")
        let hints = [NSLocalizedString("Chapter02Page06Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class StartTheAlarmBuzzerChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter02Page07Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter02Page07Hint", comment: "")]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        var containC5 = false
        var containG4 = false
        ruleTasks.forEach { (task) in
            switch task {
            case .playSound(let note, let beat):
                if note == .c5 && beat == .half {
                    containC5 = true
                }
                if note == .g4 && beat == .half {
                    containG4 = true
                }
            default:
                break
            }
        }
        callback(containC5 && containG4)
    }

    public init() {}
}

public class Challenge2Checker: RuleChecker {
    
    public var ruleTasks: [RuleTask] = [RuleTask]()
    
    public var passMessage: String = NSLocalizedString("Chapter02Page08Pass", comment: "")
    
    public var hints: [String] = [NSLocalizedString("Chapter02Page08Hint", comment: ""),
                                  NSLocalizedString("Chapter02Page08Hint2", comment: "")]
    
    public var solution: String?
    
    public func check(callback: @escaping ((Bool) -> Void)) {
        var containMotorTask = false
        var containWaitTask = false
        ruleTasks.forEach { (task) in
            switch task {
            case .dcMotor:
                containMotorTask = true
            case .wait:
                containWaitTask = true
            default:
                break
            }
        }
        callback(containMotorTask && containWaitTask)
    }
    
    public init() {}
}

public class DetectionRadarChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter03Page01Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter03Page01Hint", comment: ""),
                                  NSLocalizedString("Chapter03Page01Hint2", comment: "")]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        var hasObstacle = false
        ruleTasks.forEach { (task) in
            switch task {
            case .hasObstacle:
                hasObstacle = true
            default:
                break
            }
        }
        callback(hasObstacle)
    }

    public init() {}
}

public class DisplayChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter03Page02Pass", comment: "")
        let hints = [NSLocalizedString("Chapter03Page02Hint", comment: ""),
                     NSLocalizedString("Chapter03Page02Hint2", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class ManualModeChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter03Page03Pass", comment: "")
        let hints = [NSLocalizedString("Chapter03Page03Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class ConditionChallenge1Checker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter03Page04Pass", comment: "")
        let hints = [NSLocalizedString("Chapter03Page04Hint", comment: ""),
                     NSLocalizedString("Chapter03Page04Hint2", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class FollowFunctionChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter03Page05Pass", comment: "")
        let hints = [NSLocalizedString("Chapter03Page05Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class LightSensorChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter03Page06Pass", comment: "")
        let hints = [NSLocalizedString("Chapter03Page06Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
        self.solution = NSLocalizedString("Chapter03Page06Solution", comment: "")
    }
}

public class ConditionChallenge2Checker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()

    public var passMessage: String = NSLocalizedString("Chapter03Page07Pass", comment: "")

    public var hints: [String] = [NSLocalizedString("Chapter03Page07Hint", comment: ""),
                                  NSLocalizedString("Chapter03Page07Hint2", comment: ""),
                                  NSLocalizedString("Chapter03Page07Hint3", comment: "")]

    public var solution: String?

    public func check(callback: @escaping ((Bool) -> Void)) {
        var hasObstacle = false
        ruleTasks.forEach { (task) in
            switch task {
            case .hasObstacle:
                hasObstacle = true
            default:
                break
            }
        }
        callback(hasObstacle)
    }

    public init() {}
}

public class AwakeTheRobotChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()
    
    public var passMessage: String = NSLocalizedString("Chapter03Page09Pass", comment: "")
    
    public var hints: [String] = [NSLocalizedString("Chapter03Page09Hint", comment: "")]
    
    public var solution: String?
    
    public func check(callback: @escaping ((Bool) -> Void)) {
        var hasPanelShow = false
        ruleTasks.forEach { (task) in
            switch task {
            case .panelShow(_):
                hasPanelShow = true
            default:
                break
            }
        }
        callback(hasPanelShow)
    }
    
    public init() {}
}


public class TestTheRobotChecker: RuleChecker {
    public var ruleTasks: [RuleTask] = [RuleTask]()
    
    public var passMessage: String = NSLocalizedString("Chapter03Page10Pass", comment: "")
    
    public var hints: [String] = [NSLocalizedString("Chapter03Page10Hint", comment: ""),
                                  NSLocalizedString("Chapter03Page10Hint2", comment: ""),
                                  NSLocalizedString("Chapter03Page10Hint3", comment: "")]
    
    public var solution: String?
    
    public func check(callback: @escaping ((Bool) -> Void)) {
        var hasPlaySound = false
        var hasLedColor = false
        ruleTasks.forEach { (task) in
            switch task {
            case .playSound(_, _):
                hasPlaySound = true
            case .ledColor(_):
                hasLedColor = true
            default:
                break
            }
        }
        callback(hasPlaySound && hasLedColor)
    }
    
    public init() {}
}

public class StartTheRobotChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter03Page11Pass", comment: "")
        let hints = [NSLocalizedString("Chapter03Page11Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class SwordChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter04Page03Pass", comment: "")
        let hints = [NSLocalizedString("Chapter04Page03Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}

public class PianoChecker: NormalRunningChecker {
    public init() {
        let passMessage = NSLocalizedString("Chapter04Page05Pass", comment: "")
        let hints = [NSLocalizedString("Chapter04Page05Hint", comment: "")]
        super.init(passMessage: passMessage, hints: hints)
    }
}
