import PlaygroundSupport
import Foundation

public class RuleManager {
    public static let shared = RuleManager()

    public var ruleChecker: RuleChecker!

    public var needFinishExecution: Bool = true

    private init() {}

    public func set(ruleChecker: RuleChecker) {
        self.ruleChecker = ruleChecker
    }

    public func check() {
        if ruleChecker == nil {
            print("ruleChecker is nil.")
            return
        }

        ruleChecker.check { (value) in
            if value {
                PlaygroundPage.current.assessmentStatus = .pass(message: self.ruleChecker.passMessage)
            } else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: self.ruleChecker.hints, solution: self.ruleChecker.solution)
            }
            if self.needFinishExecution {
                PlaygroundPage.current.finishExecution()
            }
        }
    }
}

extension RuleManager {
    public func append(ruleTask: RuleTask) {
        if ruleChecker == nil {
            print("ruleChecker is nil.")
            return
        }
        self.ruleChecker.ruleTasks.append(ruleTask)
    }
}

public protocol RuleChecker {
    var ruleTasks: [RuleTask] { get set}
    var passMessage: String {get set}
    var hints: [String] {get set}
    var solution: String? {get set}
    func check(callback:@escaping ((Bool) -> Void))
}
