//
//  SwordStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/21.
//

import UIKit

public class SwordStageView: DeckStageView {
    fileprivate let animationView = UIImageView(frame: .zero)

    public override func setupGameView() {
        setBgImage(UIImage(named: "sword/sword_bg"))

        animationView.animationImages = [UIImage(named: "sword/sword_1")!,
                                         UIImage(named: "sword/sword_2")!,
                                         UIImage(named: "sword/sword_3")!,
                                         UIImage(named: "sword/sword_4")!,
                                         UIImage(named: "sword/sword_5")!,
                                         UIImage(named: "sword/sword_6")!,
                                         UIImage(named: "sword/sword_5")!,
                                         UIImage(named: "sword/sword_4")!,
                                         UIImage(named: "sword/sword_3")!,
                                         UIImage(named: "sword/sword_2")!,
                                         UIImage(named: "sword/sword_1")!]
        addSubview(animationView)
        animationView.snp.makeConstraints { (make) in
            make.height.equalTo(self)
            make.width.equalTo(animationView.snp.height).multipliedBy(0.59)
            make.center.equalTo(self)
        }
        animationView.animationDuration = 2.0
        animationView.startAnimating()
    }
}
