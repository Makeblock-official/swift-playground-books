//
//  KnobViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import PlaygroundBluetooth
import AVFoundation

public class KnobViewController: LiveViewController {

    public let stageView = KnobStageView.init(frame: .zero)

    override public func viewDidLoad() {
        setBackgroundAudio(visible: false)
        super.viewDidLoad()
        loadStage()
    }

    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        stageView.updateLayout(frame: view.frame)
    }

    public override func onStartRunning() {
        stageView.playGIF()
    }

    public override func onStopRunning() {
        stageView.stopGIF()
        stopMusic()
    }

    public func iPadmusic(note: Int) {
        var resource = note/10 + 1
        if resource < 1 {
            resource = 1
        } else if resource > 9 {
            resource = 1
        }

        let path = Bundle.main.path(forResource: "knob/\(resource)", ofType: "m4a")
        let url = URL(fileURLWithPath: path!)
        playMusic(url: url)
    }

    public override func didConnect() {
        stageView.moveCurtain(position: .out)
    }
    
    public override func didDisconnect() {
        stageView.moveCurtain(position: .down)
    }

    private func loadStage() {
        view.addSubview(stageView)
        stageView.hideKnob()
    }
}
