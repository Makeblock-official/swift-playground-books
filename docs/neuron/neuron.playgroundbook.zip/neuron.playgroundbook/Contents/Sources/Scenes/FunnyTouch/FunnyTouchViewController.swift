//
//  FunnyTouchViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit

public class FunnyTouchViewController: LiveViewController {

    public let stageView = FunnyTouchStageView(frame: .zero)

    override public func viewDidLoad() {
        super.viewDidLoad()
        loadStage()
    }

    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        stageView.updateLayout(frame: view.frame)
    }

    public override func onStartRunning() {
        stageView.startRandom()
    }

    public override func onStopRunning() {
        stageView.stopRandom()
    }
    
    public override func didConnect() {
        stageView.moveCurtain(position: .out)
    }
    
    public override func didDisconnect() {
        stageView.moveCurtain(position: .down)
    }

    public func hammer(color: Int) {
        if color == 1 {
            stageView.hammer(position: .blue)
        } else if color == 2 {
            stageView.hammer(position: .yellow)
        } else if color == 3 {
            stageView.hammer(position: .red)
        } else if color == 4 {
            stageView.hammer(position: .green)
        }
    }

    private func loadStage() {
        view.addSubview(stageView)
    }
}
