//
//  KnowNeuron.swift
//  Neuron
//
//  Created by littleStrong on 2018/3/16.
//  Copyright © 2018年 Company. All rights reserved.
//

import UIKit

public class KnowNeuronStageView: StageView {
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)
    fileprivate let robotGifImageView = UIImageView(frame: .zero)

    fileprivate let defaultImageView = UIImageView.init(image: UIImage.init(named: "lightSensor_defalut"))

    fileprivate let lightImageView = UIImageView.init(image: UIImage.init(named: "light_off"))
    fileprivate let shadowImageView = UIImageView.init(image: UIImage.init(named: "shadow"))
    fileprivate let spotImageView = UIImageView.init(image: UIImage.init(named: "spot_cyan"))
    fileprivate let robotExpressionImageView = UIImageView.init(image: UIImage.init(named: "expression_blank"))

    fileprivate let planeImageView = UIImageView.init(image: UIImage.init(named: "distance_plane"))

    fileprivate var isLightDown: Bool = false

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "stage"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override public func setupGameView() {
        clipsToBounds = true

        shadowImageView.isHidden = true
        shadowImageView.contentMode = .scaleAspectFill
        addSubview(shadowImageView)

        defaultImageView.contentMode = .scaleAspectFill
        defaultImageView.clipsToBounds = true
        defaultImageView.alpha = 0
        addSubview(defaultImageView)

        addSubview(spotImageView)

        addSubview(lightImageView)

        robotExpressionImageView.contentMode = .scaleAspectFill
        robotExpressionImageView.isHidden = true
        addSubview(robotExpressionImageView)

        robotGifImageView.contentMode = .scaleAspectFill
        addSubview(robotGifImageView)

        planeImageView.contentMode = .scaleAspectFill
        planeImageView.clipsToBounds = true
        addSubview(planeImageView)
    }

    override public func updateLayout(frame: CGRect) {
        super.updateLayout(frame: frame)

        defaultImageView.frame = bounds

        shadowImageView.frame = bounds
        robotExpressionImageView.frame = bounds
        robotGifImageView.frame = bounds
        planeImageView.frame = bounds

        lightImageView.frame = getLightFrame()
        configSpot()
        animatePlane(percent: 0.6, animated: false)
    }

    // MARK: Public

    public func hideCharacter() {
        robotGifImageView.isHidden = true
    }

    public func showCharacter() {
        stopGIF()
    }

    public func hidePlane(_ animated: Bool) {
        if animated {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.planeImageView.alpha = 0
            }, completion: nil)
        } else {
            planeImageView.alpha = 0
        }

    }

    public func showDefaultLightSensor(_ animated: Bool = true) {
        defaultImageView.image = UIImage.init(named: "lightSensor_defalut")
        if animated {
            UIView.animate(withDuration: 0.7, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.defaultImageView.alpha = 1
            }, completion: nil)
        } else {
            self.defaultImageView.alpha = 1
        }
    }

    public func hideDefaultLightSensor(_ animated: Bool = false) {
        defaultImageView.image = UIImage.init(named: "lightSensor_defalut")
        if animated {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.defaultImageView.alpha = 0
            }, completion: nil)
        } else {
            self.defaultImageView.alpha = 0
        }
    }

    public func showPlane(_ animated: Bool) {
        if animated {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.planeImageView.alpha = 1
            }, completion: nil)
        } else {
            planeImageView.alpha = 1
        }
    }

    public func playGIF(_ type: AnimationType, loopCount: Int = -1) {
        guard type != .none else {
            stopGIF()
            return
        }
        robotGifImageView.isHidden = false
        robotGifImageView.setGifImage(UIImage(gifName: type.rawValue), manager: gifManager, loopCount: loopCount)
        robotGifImageView.startAnimatingGif()
        shadowImageView.isHidden = true
    }

    public func showExpression(_ type: Expression) {
        robotExpressionImageView.isHidden = false
        robotExpressionImageView.image = UIImage.init(named: type.imgName)
    }

    public func hideExpression() {
        robotExpressionImageView.isHidden = true
    }

    public func stopGIF() {
        shadowImageView.isHidden = false
        robotGifImageView.isHidden = false
        let image = UIImage(gifName: "robot_s")
        robotGifImageView.setGifImage(image, manager: gifManager, loopCount: 0)
        let count = image.framesCount()
        robotGifImageView.showFrameAtIndex(count - 1)
    }

    public func clearGIF() {
       robotGifImageView.clear()
    }

    public func animatePlane(percent: CGFloat, animated: Bool = true) {
        let finalPercent = percent > 1.0 ? 1.0 : percent
        var frameImage = planeImageView.frame
        let heighDelata: CGFloat = 520 / 1536 * bounds.height
        frameImage.origin.y = -finalPercent * heighDelata
        if animated {
            UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.planeImageView.frame = frameImage
            }, completion: nil)
        } else {
            planeImageView.frame = frameImage
        }
    }

    public func showDefaultStage() {
        hidePlane(true)
        hideCharacter()
        hideExpression()
        hideDefaultLightSensor(true)
        moveLight(down: false)
        clearGIF()
    }

    public func moveLight(down: Bool, animated: Bool = true) {
        isLightDown = down
        if animated {
            UIView.animate(withDuration: 0.7, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.lightImageView.frame = self.getLightFrame()
            }, completion: nil)
        } else {
            lightImageView.frame = frame
        }
    }

    public func turnSpot(isOpen: Bool, color: LEDColor = .white, animated: Bool = true) {
        let action = { () -> Void in
            if isOpen {
                self.spotImageView.alpha = 1
                let spotImgName = "spot_\(color.imgName)"
                let lightImgName = "light_\(color.imgName)"
                self.spotImageView.image = UIImage.init(named: spotImgName)
                self.lightImageView.image = UIImage.init(named: lightImgName)
            } else {
                self.spotImageView.alpha = 0
            }
        }
        if animated {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.85, initialSpringVelocity: 0, options: .curveEaseInOut, animations: action, completion: nil)
        } else {
            action()
        }
    }

    // MARK: Config Layout

    fileprivate func configSpot() {
        let height: CGFloat = 467.5 * aspect
        let width: CGFloat = 426 * aspect
        let x = bounds.width / 2 - CGFloat(width / 2)
        let y = 188 * aspect
        spotImageView.frame = CGRect.init(x: x, y: y, width: width, height: height)
    }

    fileprivate func getLightFrame() -> CGRect {
        let height: CGFloat = 492.5 * aspect
        let width: CGFloat = 446 * aspect
        let x = bounds.width / 2 - CGFloat(width / 2)
        var y = -200 * aspect
        if !isLightDown {
            y = -600 * aspect
        }
        return CGRect.init(x: x, y: y, width: width, height: height)
    }
}

public enum AnimationType: String {
    case goodbye = "say goodbye"
    case hello = "say hello"
    case sing
    case lightDefault = "light_default"
    case lightGetDark = "light_getDark"
    case lightGetBright = "light_getBright"
    case distanceStageOpen = "distance_stage_open"
    case distanceFlyBack = "distance_fly_back"
    case none
}

extension LEDColor {
    public var imgName: String {
        switch self {
        case .black:
            return "black"
        case .red:
            return "red"
        case .orange:
            return "orange"
        case .yellow:
            return "yellow"
        case .green:
            return "green"
        case .cyan:
            return "cyan"
        case .blue:
            return "blue"
        case .purple:
            return "purple"
        case .white:
            return "white"
        }
    }
}
