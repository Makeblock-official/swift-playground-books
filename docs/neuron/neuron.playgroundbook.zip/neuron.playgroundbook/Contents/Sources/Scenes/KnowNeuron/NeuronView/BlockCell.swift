//
//  BlockCell.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/17.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit

class BlockCell: UITableViewCell {

    var centerImageView: UIImageView!

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        centerImageView = UIImageView()
        centerImageView.contentMode = .scaleAspectFit
        backgroundColor = UIColor.clear
        selectionStyle = .none
        contentView.addSubview(centerImageView)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    public var model: BlockCellModel = BlockCellModel() {
        didSet {
            centerImageView.image = fetchImage(model.imageName)
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        centerImageView.frame = contentView.bounds
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = UIColor.clear
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
