//
//  PianoViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/21.
//

import UIKit

public class PianoViewController: LiveViewController {
    public let stageView = PianoStageView(frame: CGRect.zero)

    override public func viewDidLoad() {
        super.viewDidLoad()
        self.setBackgroundAudio(visible: false)
        setupStageView()
    }

    override public func onStopRunning() {
        Loader.currentBot.setBothDCMotor(speed1: 0, speed2: 0)
    }
    
    public override func didConnect() {
        stageView.moveCurtain(position: .top)
    }
    
    public override func didDisconnect() {
        stageView.moveCurtain(position: .down)
    }

    func setupStageView() {
        view.addSubview(stageView)
        stageView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        stageView.updateLayout(frame: view.frame)
    }
}
