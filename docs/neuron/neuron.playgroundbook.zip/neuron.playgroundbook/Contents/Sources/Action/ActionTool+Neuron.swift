//
//  ActionTool+Neuron.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/8/6.
//

import Foundation
import UIKit

extension ActionTool {
    static public func powerOn() {
        sendAction(.powerOn, duration: 0.5)
    }
    
    static public func powerOff() {
        sendAction(.powerOff)
    }
    
    static public func getKnob() {
        sendAction(.getKnob)
    }
    
    static public func getLight() {
        sendAction(.getLight)
    }
    
    static public func getTemperature() {
        sendAction(.getTemperature)
    }
    
    static public func getDistance() {
        sendAction(.getDistance)
    }
    
    static public func getFunnyTouch() {
        sendAction(.getFunnyTouch)
    }
    
    static public func changeLightIntensity(_ light: Float) {
        sendAction(.lightSensor(lightIntensity: light), duration: 0)
    }
    
    static public func playSound(note: SoundNote, beat: SoundBeat) {
        let extra: Float = (beat == .whole) ? 0.2 : 0.5
        let duration = Float(beat.rawValue / 1000) + extra
        sendAction(.sound(note: note, beat: beat), duration: duration)
    }
    
    static public func dcMotor(slot: DCMotorSlot, power: Int) {
        sendAction(.dcMotor(slot: slot, power: power), duration: ActionTool.DefaultDuration)
    }
    
    static public func dcMotor(power1: Int, power2: Int) {
        sendAction(.dcMotorMeanwhile(power1: power1, power2: power2), duration: ActionTool.DefaultDuration)
    }
    
    static public func ledColor(color: LEDColor, style: LEDStyle) {
        sendAction(.ledBand(color: color, style: style), duration: ActionTool.DefaultDuration)
    }
    
    static public func ledColors(colors: [LEDColor], style: LEDStyle) {
        sendAction(.ledBandColors(colors: colors, style: style), duration: ActionTool.DefaultDuration)
    }
    
    static public func panelRobotShow(_ expression: Expression) {
        sendAction(.ledPanel(expression: expression), duration: ActionTool.DefaultDuration)
    }
    
    static public func panelShow(expression: Expression) {
        sendAction(.ledPanel(expression: expression), duration: ActionTool.DefaultDuration)
    }
    
    static public func panelColor(r: Int, g: Int, b: Int) {
        sendAction(.panelColor(r: r, g: g, b: b), duration: ActionTool.DefaultDuration)
    }
    
    static public func setServo(port: ServoPort, angle: Int) {
        sendAction(.servo(port: port, angle: angle), duration: 1)
    }
    
    static public func turnLED(x: Int, y: Int, r: Int, g: Int, b: Int) {
        sendAction(.led(x: x, y: y, r: r, g: g, b: b), duration: ActionTool.DefaultDuration)
    }
    
    static public func distance(_ height: Int) {
        sendAction(.distanceSensor(distance: height), duration: ActionTool.DefaultDuration)
    }
    
    static public func iPadmusic(_ note: Int) {
        sendAction(.iPadmusic(note: note), duration: ActionTool.DefaultDuration)
    }
    
    static public func thermometer(_ temperature: Int) {
        sendAction(.thermometer(temperature: temperature), duration: ActionTool.DefaultDuration)
    }
    
    static public func hammer(_ color: Int) {
        sendAction(.hammer(color: color), duration: 5)
    }
    
    static public func iPadSound(note: PadSoundNote) {
        sendAction(.iPadSound(note: note), duration: ActionTool.DefaultDuration)
    }
    
    static public func stopiPadSound() {
        sendAction(.stopiPadSound, duration: ActionTool.DefaultDuration)
    }
}

extension BlockType {
    var imageName: String {
        switch self {
        case .dcmotor:
            return "neu-block-dcmotor"
        case .servo:
            return "neu-block-servo"
        case .light:
            return "neu-block-light"
        case .distance:
            return "neu-block-distance"
        case .gyro:
            return "neu-block-gyro"
        case .soilMoisture:
            return "neu-block-soil"
        case .voice:
            return "neu-block-voice"
        case .temperature:
            return "neu-block-temperature"
        case .funnyTouch:
            return "neu-block-funny"
        case .led:
            return "neu-block-led"
        case .ledBand:
            return "neu-block-ledBand"
        case .buzzer:
            return "neu-block-buzzer"
        case .bluetooth:
            return "neu-block-ble"
        case .power:
            return "neu-block-power"
        case .knob:
            return "neu-block-knob"
        }
    }
    
    var valueName: String {
        switch self {
        case .dcmotor:
            return "dcmotor"
        case .servo:
            return "Servo"
        case .light:
            return "LightSendor"
        case .distance:
            return "Distance"
        case .gyro:
            return "Gyro"
        case .soilMoisture:
            return "SoilMoisture"
        case .voice:
            return "Voice"
        case .temperature:
            return "Temperature"
        case .funnyTouch:
            return "FunnyTouch"
        case .led:
            return "LED"
        case .ledBand:
            return "ledBand"
        case .buzzer:
            return "Buzzer"
        case .bluetooth:
            return "Bluetooth"
        case .power:
            return "Power"
        case .knob:
            return "knob"
        }
    }
    
    var height: CGFloat {
        switch self {
        case .dcmotor:
            return 94
        case .servo:
            return 94
        case .light:
            return 56
        case .distance:
            return 56
        case .gyro:
            return 56
        case .soilMoisture:
            return 56
        case .voice:
            return 56
        case .temperature:
            return 56
        case .funnyTouch:
            return 94
        case .led:
            return 70
        case .ledBand:
            return 112
        case .buzzer:
            return 56
        case .bluetooth:
            return 123
        case .power:
            return 91
        case .knob:
            return 91
        }
    }
}
