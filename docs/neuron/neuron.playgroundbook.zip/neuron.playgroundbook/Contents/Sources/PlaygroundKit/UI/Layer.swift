//
//  Layer.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/8.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import UIKit

extension UIView {
    @IBInspectable public var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
        get {return layer.cornerRadius}
    }
}
