//
//  MakeblockCommand.swift
//  Neuron
//
//  Created by CatchZeng on 2017/7/4.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public protocol MakeblockCommand {
    var data: Data { get }
}

public protocol MakeblockSender: class {
    func send(data: Data)
}
