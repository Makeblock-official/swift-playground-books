//
//  BluetoothDevice.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import CoreBluetooth

public protocol PeripheralDelegate: class {
    func peripheral(_ peripheral: Peripheral, didDiscover services: [CBService]?, error: Error?)
    func peripheral(_ peripheral: Peripheral, didDiscover characteristics: [CBCharacteristic]?, error: Error?)
}

public protocol PeripheralDataDelegate: class {
    func peripheral(_ peripheral: Peripheral, didReceive data: Data)
}

public class Peripheral: NSObject, CBPeripheralDelegate {
    public weak var delegate: PeripheralDelegate?
    public weak var dataDelegate: PeripheralDataDelegate?
    public var name = ""
    public var uuid = ""
    public var rssi: Float = 100
    var peripheral: CBPeripheral!
    var writeChar: CBCharacteristic?
    
    private var sendHandler: ((Result<(Peripheral, Data)>) -> Void)?

    public override var description: String {
        return "\(name) uuid:\(uuid) rssi:\(rssi)"
    }

    private var writeBuffer: WriteBuffer?

    init(peripheral: CBPeripheral, rssi: Float? = nil) {
        super.init()
        self.peripheral = peripheral
        peripheral.delegate = self
        name = peripheral.name ?? ""
        uuid = peripheral.identifier.uuidString
        if let r = rssi {
            self.rssi = r
        }
    }

    func send(data: Data, to writeChar: CBCharacteristic, type: CBCharacteristicWriteType) {
        if writeBuffer == nil {
            writeBuffer = WriteBuffer(peripheral: peripheral, writeChar: writeChar)
        }
        writeBuffer?.add(data: data)
    }

    // MARK: Delegate

    public func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        delegate?.peripheral(self, didDiscover: peripheral.services, error: error)
    }

    public func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        delegate?.peripheral(self, didDiscover: service.characteristics, error: error)
    }

    public func peripheral(_ peripheral: CBPeripheral, didReadRSSI RSSI: NSNumber, error: Error?) {
        rssi = RSSI.floatValue
    }

    public func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let data = characteristic.value {
            dataDelegate?.peripheral(self, didReceive: data)
        }
    }
}
