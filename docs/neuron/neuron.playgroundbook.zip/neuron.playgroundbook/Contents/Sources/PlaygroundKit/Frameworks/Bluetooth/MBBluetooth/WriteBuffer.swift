import Foundation
import CoreBluetooth

open class WriteBuffer {
    public var timeInterval: TimeInterval = 0.01

    private var buffers = [Data]()
    private var lock = NSLock()
    private var timer: Timer?

    private var peripheral: CBPeripheral
    private var writeChar: CBCharacteristic

    public init(peripheral: CBPeripheral, writeChar: CBCharacteristic) {
        self.peripheral = peripheral
        self.writeChar = writeChar
    }

    public func add(data: Data) {
        lock.lock()
        buffers.append(data)
        lock.unlock()

        startTimer()
    }

    private func startTimer() {
        stopTimer()

        timer = Timer.scheduledTimer(timeInterval: timeInterval,
                                     target: self,
                                     selector: #selector(send),
                                     userInfo: nil,
                                     repeats: true)
    }

    private func stopTimer() {
        timer?.invalidate()
    }

    @objc private func send() {
        if buffers.count < 1 {
            stopTimer()
            return
        }

        lock.lock()
        let data = buffers.first
        buffers.removeFirst()
        lock.unlock()

        peripheral.writeValue(data!,
                              for: writeChar,
                              type: .withoutResponse)
    }
}
