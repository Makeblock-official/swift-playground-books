//
//  BlueToothProvider.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import CoreBluetooth

public protocol PeripheralConfiguratorDelegate: class {
    func peripheralDidPrepared(_ peripheral: Result<Peripheral>)
}

public final class PeripheralConfigurator: PeripheralDelegate {
    public weak var delegate: PeripheralConfiguratorDelegate?
    private var peripheral: Peripheral!
    private var isDual: Bool = false
    private var resetService: CBService?
    private var transService: CBService?
    private var resetCharateristic: CBCharacteristic?
    private var transCharateristic: CBCharacteristic?
    private var notifyCharateristic: CBCharacteristic?

    public func prepare(peripheral: Peripheral) {
        self.peripheral = peripheral
        peripheral.delegate = self
        peripheral.peripheral.discoverServices(nil)
    }

    public func peripheral(_ peripheral: Peripheral, didDiscover services: [CBService]?, error: Error?) {
        guard let services = services else { return }
        for service in services {
            switch service.uuid {
            case CBUUID.transDataService:
                peripheral.peripheral.discoverCharacteristics([.transDataCharateristic, .transDataDualCharateristic, .notifyDataCharateristic, .notifyDataDualCharateristic], for: service)
            case CBUUID.transDataDualService:
                isDual = true
                peripheral.peripheral.discoverCharacteristics([.transDataCharateristic, .transDataDualCharateristic, .notifyDataCharateristic, .notifyDataDualCharateristic], for: service)
            default:
                continue
            }
        }
    }

    public func peripheral(_ peripheral: Peripheral, didDiscover characteristics: [CBCharacteristic]?, error: Error?) {
        guard let characteristics = characteristics, error == nil else {
            return
        }
        for characteristic in characteristics {
            switch characteristic.uuid {
            case CBUUID.transDataCharateristic, CBUUID.transDataDualCharateristic:
                transCharateristic = characteristic
            case CBUUID.notifyDataCharateristic, CBUUID.notifyDataDualCharateristic:
                notifyCharateristic = characteristic
                peripheral.peripheral.setNotifyValue(true, for: characteristic)
            default:
                continue
            }
            notifyPrepared()
        }
    }

    // MARK: Private
    
    private func notifyPrepared() {
        if notifyCharateristic != nil && transCharateristic != nil {
            peripheral.writeChar = transCharateristic
            delegate?.peripheralDidPrepared(.success(peripheral))
        }
    }
}
