//
//  BluetoothConstant.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import CoreBluetooth
import Foundation

extension CBUUID {
    @nonobjc static let transDataService = CBUUID(string: "FFF0")
    @nonobjc static let transDataDualService = CBUUID(string: "FFE1")

    @nonobjc static let transDataCharateristic = CBUUID(string: "FFF1")
    @nonobjc static let transDataDualCharateristic = CBUUID(string: "FFE3")
    @nonobjc static let notifyDataCharateristic = CBUUID(string: "FFF4")
    @nonobjc static let notifyDataDualCharateristic = CBUUID(string: "FFE2")
}

struct Makeblock {
    static let prefix = "Makeblock"
    static let neuronPrefix = "Neuron"
}
