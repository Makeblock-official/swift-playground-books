//
//  BlockContainer.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public protocol BlockContainerDelegate: class {
    func didConnect(block: BlockType, on position: Int)
    func didDisConnect(block: BlockType, on position: Int)
}

public struct BlockChecker {
    var blockType: BlockType
    var needSkipCheck: Bool
    var offlineCount: Int

    public init(blockType: BlockType) {
        self.blockType = blockType
        self.needSkipCheck = true
        self.offlineCount = 0
    }
}

open class BlockContainer {
    public weak var delegate: BlockContainerDelegate?

    private static let maxAllowOfflineTimes = 3
    private static let checkTimeInterval: TimeInterval = 0.5

    private(set) var blocks: [Int: BlockChecker] = [Int: BlockChecker]()
    private var timer: Timer?
    private var isTiming = false

    public init() {
        startTimer()
    }

    deinit {
        stopTimer()
    }

    public func startTimer() {
        if isTiming {
            return
        }

        isTiming = true
        timer = Timer.scheduledTimer(timeInterval: BlockContainer.checkTimeInterval,
                                     target: self,
                                     selector: #selector(checkOffline),
                                     userInfo: nil,
                                     repeats: true)
    }

    public func stopTimer() {
        timer?.invalidate()
        isTiming = false
    }

    public func receive(dispatchPackage: DispatchPackage) {
        guard let blockType = dispatchPackage.blockType else {
            return
        }

        startTimer()

        let position = dispatchPackage.blockNo
        var block = blocks[position]

        if block == nil {
            blocks[position] = BlockChecker(blockType: blockType)
            delegate?.didConnect(block: blockType, on: position)
        } else {
            block?.offlineCount = 0
            block?.needSkipCheck = true
            blocks[position] = block
        }
    }

    // MARK: Private Methods

    @objc private func checkOffline() {
        if blocks.count < 1 {
            stopTimer()
            return
        }

        blocks.forEach { (key, value) in
            var tmpValue = value

            if value.needSkipCheck {
                tmpValue.needSkipCheck = false
                blocks[key] = tmpValue

            } else {
                tmpValue.offlineCount += 1
                if tmpValue.offlineCount>=BlockContainer.maxAllowOfflineTimes {
                    blocks[key] = nil
                    delegate?.didDisConnect(block: tmpValue.blockType, on: key)

                } else {
                    blocks[key] = tmpValue
                }
            }
        }
    }
}
