//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
    ActionTool.setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed)
}

public func setLEDLight(r: Int, g: Int, b: Int) {
    ActionTool.setLEDLight(r: r, g: g, b: b)
}

public func playMusic(type: MusicType) {
    ActionTool.playMusic(type: type)
}

public func setFacePanel(x: Int, y: Int, isOn: Bool) {
    ActionTool.setFacePanel(x: x, y: y, isOn: isOn)
}

public func setFacePanel(type: FacePanelType) {
    ActionTool.setFacePanel(type: type)
}

public func clearFacePanel() {
    ActionTool.clearFacePanel()
}

public func playMusic(note: SoundNote, beat: SoundBeat) {
    ActionTool.playMusic(note: note, beat: beat)
}

public func readLightSensor() -> Float {
    wait(duration: 0.1)
    ActionTool.readLightSensor()
    return contentListenr.lightIntensity
}

public func readSoundSensor() -> Float {
    wait(duration: 0.1)
    ActionTool.readSoundSensor()
    return contentListenr.soundIntensity
}

public func readGyroRoll() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    return contentListenr.roll
}

public func readGyroPitch() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    return contentListenr.pitch
}

public func readGyroYaw() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    return contentListenr.yaw
}

public func readGyroAccX() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    return contentListenr.accX
}

public func readGyroAccY() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    return contentListenr.accY
}

public func readGyroAccZ() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    return contentListenr.accZ
}

public func buttonAPressed() -> Bool {
    wait(duration: 0.1)
    ActionTool.getButtonState()
    return contentListenr.buttonAPressed
}

public func buttonBPressed() -> Bool {
    wait(duration: 0.1)
    ActionTool.getButtonState()
    return contentListenr.buttonBPressed
}

public func buttonCPressed() -> Bool {
    wait(duration: 0.1)
    ActionTool.getButtonState()
    return contentListenr.buttonCPressed
}

public func readPotentiometer() -> Float {
    wait(duration: 0.1)
    ActionTool.readPotentiometer()
    return contentListenr.potentiometer
}

public func shaked() -> Bool {
    wait(duration: 0.1)
    ActionTool.getShake()
    return contentListenr.shaked
}

public func readColorSensor() -> ColorType {
    wait(duration: 0.1)
    ActionTool.readColorSensor()
    return contentListenr.color
}

public func hasObstacle() -> Bool {
    wait(duration: 0.1)
    ActionTool.hasObstacle()
    return contentListenr.hasObstacle
}

public func iPadTiltedForward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedForward
}

public func iPadTiltedBackward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedBackward
}

public func iPadTiltedLeft() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedLeft
}

public func iPadTiltedRight() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedRight
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
