//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
    ActionTool.setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed)
}

public func setLEDLight(r: Int, g: Int, b: Int) {
    ActionTool.setLEDLight(r: r, g: g, b: b)
}

public func playMusic(type: MusicType) {
    ActionTool.playMusic(type: type)
}

public func setFacePanel(x: Int, y: Int, isOn: Bool) {
    ActionTool.setFacePanel(x: x, y: y, isOn: isOn)
}

public func setFacePanel(type: FacePanelType) {
    ActionTool.setFacePanel(type: type)
}

public func clearFacePanel() {
    ActionTool.clearFacePanel()
}

public func playMusic(note: SoundNote, beat: SoundBeat) {
    ActionTool.playMusic(note: note, beat: beat)
}

public func readLightSensor() -> Float {
    wait(duration: 0.1)
    ActionTool.readLightSensor()
    
    let t1=CACurrentMediaTime()
    while contentListenr.lightIntensity == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.lightIntensity
}

public func readSoundSensor() -> Float {
    wait(duration: 0.1)
    ActionTool.readSoundSensor()
    
    let t1=CACurrentMediaTime()
    while contentListenr.soundIntensity == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.soundIntensity
}

public func readGyroRoll() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    
    let t1=CACurrentMediaTime()
    while contentListenr.roll == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.roll
}

public func readGyroPitch() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    
    let t1=CACurrentMediaTime()
    while contentListenr.pitch == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.pitch
}

public func readGyroYaw() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    
    let t1=CACurrentMediaTime()
    while contentListenr.yaw == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.yaw
}

public func readGyroAccX() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    
    let t1=CACurrentMediaTime()
    while contentListenr.accX == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.accX
}

public func readGyroAccY() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    
    let t1=CACurrentMediaTime()
    while contentListenr.accY == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.accY
}

public func readGyroAccZ() -> Float {
    wait(duration: 0.1)
    ActionTool.getGyro()
    
    let t1=CACurrentMediaTime()
    while contentListenr.accZ == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.accZ
}

public func buttonAPressed() -> Bool {
    wait(duration: 0.1)
    ActionTool.getButtonState()
    
    let t1=CACurrentMediaTime()
    while contentListenr.buttonAPressed == false {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.buttonAPressed
}

public func buttonBPressed() -> Bool {
    wait(duration: 0.1)
    ActionTool.getButtonState()
    
    let t1=CACurrentMediaTime()
    while contentListenr.buttonBPressed == false {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.buttonBPressed
}

public func buttonCPressed() -> Bool {
    wait(duration: 0.1)
    ActionTool.getButtonState()
    
    let t1=CACurrentMediaTime()
    while contentListenr.buttonCPressed == false {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.buttonCPressed
}

public func readPotentiometer() -> Float {
    wait(duration: 0.1)
    ActionTool.readPotentiometer()
    
    let t1=CACurrentMediaTime()
    while contentListenr.potentiometer == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.potentiometer
}

public func shaked() -> Bool {
    wait(duration: 0.1)
    ActionTool.getShake()
    
    let t1=CACurrentMediaTime()
    while contentListenr.shaked == false {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.shaked
}

public func readColorSensor() -> ColorType {
    wait(duration: 0.1)
    ActionTool.readColorSensor()
    
    let t1=CACurrentMediaTime()
    while contentListenr.color == .unknown {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.color
}

public func hasObstacle() -> Bool {
    wait(duration: 0.1)
    ActionTool.hasObstacle()
    
    let t1=CACurrentMediaTime()
    while contentListenr.hasObstacle {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.3 {
            break
        }
    }
    return contentListenr.hasObstacle
}

public func iPadTiltedForward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedForward
}

public func iPadTiltedBackward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedBackward
}

public func iPadTiltedLeft() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedLeft
}

public func iPadTiltedRight() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedRight
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
