//
//  MessageCommand.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport

public enum PlatformType: String, SPMessageConstructible {
    case bluetooth
    case all
    
    public init?(_ value: PlaygroundValue) {
        guard case let .string(stringValue) = value,
            let type = PlatformType.init(rawValue: stringValue) else {
            return nil
        }
        self = type
    }

    public var value: PlaygroundValue {
        return .string(rawValue)
    }
}

public protocol SPCommand: SPMessageConstructible {
    associatedtype ActionType: SPMessageConstructible

    var platform: PlatformType {get}
    var action: ActionType {get}
    var duration: Float {get}
}

public struct MCommand: SPCommand {
    public var platform: PlatformType

    public var duration: Float

    public typealias ActionType = SPCommandAction

    public var action: ActionType
    
    public init(action: ActionType, duration: Float = 2, platform: PlatformType = .all) {
        self.action = action
        self.duration = duration
        self.platform = platform
    }
    
    public init() {
        self.action = .none
        self.duration = 0
        self.platform = .all
    }
}

extension MCommand: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value,
            let action = dict["action"],
            let durationValue = dict["duration"],
            case let .floatingPoint(duration) = durationValue,
            let platform = dict["platform"],
            let pType = PlatformType.init(platform) else {
                return nil
        }
        
        self.action = SPCommandAction.init(action) ?? SPCommandAction.execute
        self.duration = Float(duration)
        self.platform = pType
    }

    public var value: PlaygroundValue {
        return .dictionary(["action": action.value, "duration": duration.value, "platform": platform.value])
    }
}
