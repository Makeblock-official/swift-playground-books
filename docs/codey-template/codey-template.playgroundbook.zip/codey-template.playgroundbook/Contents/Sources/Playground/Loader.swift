//
//  Loader.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport

public struct Loader {
    public static var currentProxy: PlaygroundRemoteLiveViewProxy? {
        return PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
    }

    public static let sharedTaskMgr: SPTaskManager<MCommand> = SPTaskManager<MCommand>()
    
    public static let currentBot = Codey(sender: SPBLECenter.shared)
    
    public static var currentLiveViewController: TemplateViewController? {
        if let vc = PlaygroundPage.current.liveView as? TemplateViewController {
            return vc
        }
        return nil
    }
}
