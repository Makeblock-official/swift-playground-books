//
//  PlaygroundHelpers.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundSupport
import UIKit

/// Waits for a number of seconds before running the next sequence of code.
///
/// - Parameter seconds: the number of seconds to wait
func wait(_ seconds: Double) {
    usleep(UInt32(seconds * 1e6))
}
public func log(_ text: String, _ index: Int = 0) {
    Loader.currentLiveViewController?.log(text)
}

public func setCurrentScene(chapter: Int = 0, page: Int = 0) {
    let vc = TemplateViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setProxyDelegate(_ delegate: PlaygroundRemoteLiveViewProxyDelegate) {
    if let proxy = Loader.currentProxy {
        proxy.delegate = delegate
    }
}

public func sendToLiveView(_ value: PlaygroundValue) {
    if let proxy = Loader.currentProxy {
        proxy.send(value)
    }
}

public func sendToContents(_ value: PlaygroundValue) {

    if let proxy = PlaygroundPage.current.liveView as? PlaygroundLiveViewMessageHandler {
        proxy.send(value)
    }
}

public func sendToContentsWithEnum(_ enumValue: SPCallbackCommand) {
    sendToContents(enumValue.value)
}

/// Instantiates a new instance of a live view.
///
/// By default, this loads an instance of `LiveViewController` from `LiveView.storyboard`.
public func instantiateLiveView() -> PlaygroundLiveViewable {
    //    let storyboard = UIStoryboard(name: "LiveView", bundle: nil)
    //
    //    guard let viewController = storyboard.instantiateInitialViewController() else {
    //        fatalError("LiveView.storyboard does not have an initial scene; please set one or update this function")
    //    }
    
    //    guard let liveViewController = viewController as? LiveViewController else {
    //        fatalError("LiveView.storyboard's initial scene is not a LiveViewController; please either update the storyboard or this function")
    //    }
    let liveViewController = TemplateViewController()
    return liveViewController
}
