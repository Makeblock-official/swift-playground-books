//
//  Codey.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/7/31.
//

import Foundation

public class Codey: NSObject {
    
    private var sender: MakeblockSender?
    private let parse = NeuronDataParser()
    private let interpreter = CodeyInterpreter()
    private var lightIntensityCallback: ((Float) -> Void)?
    private var buttonCallback: ((Bool, Bool, Bool) -> Void)?
    private var potentiometerCallback: ((Float) -> Void)?
    private var soundIntensityCallback: ((Float) -> Void)?
    private var gyroCallback: ((Float, Float, Float, Float, Float, Float) -> Void)?
    private var shakeCallback: ((Bool) -> Void)?
    private var hasObstacleCallback: ((Bool) -> Void)?
    private var colorCallback: ((ColorType) -> Void)?
    
    public init(sender: MakeblockSender) {
        super.init()
        self.sender = sender
        parse.delegate = self
        interpreter.delegate = self
    }
    
    public func didReceive(data: Data) {
        if data.hexString == "f3f603000d00010ef4" {
            let hexString = "F0 FF 10 00 0F F7"
            if let data = hexString.hexadecimal() { // set ID
                sender?.send(data: data)
            }
        } else {
            parse.addReceived(data: data)
        }
    }
    
    public func changeToOnline() {
        let hexString = "F3 F6 03 00  0D  00 01 0E F4"
        if let data = hexString.hexadecimal() {
            sender?.send(data: data)
        }
    }
    
    public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
        let left = Int(Float(leftSpeed)/2.55)
        let right = Int(Float(rightSpeed)/2.55)
        let command = MoveCommand(left: left, right: -right)
        send(command: command)
    }
    
    public func playMusic(type: MusicType) {
        let fileName = type.rawValue + ".wav"
        let command = SoundCommand(fileName: fileName)
        send(command: command)
    }
    
    public func playMusic(note: SoundNote, beat: SoundBeat) {
        let command = SoundNoteCommand(note: note, beat: beat)
        send(command: command)
    }
    
    public func setFacePanel(x: Int, y: Int, isOn: Bool) {
        let common = FacePanelPixelCommand(x: x, y: y, isOn: isOn)
        send(command: common)
    }
    
    public func setFacePanel(type: FacePanelType) {
        let common = FacePanelCommand(hexStr: type.rawValue)
        send(command: common)
    }
    
    public func clearFacePanel() {
        let common = ClearFacePanelCommand()
        send(command: common)
    }
    
    public func setLEDLight(r: Int, g: Int, b: Int) {
        let red = UInt8(Float(r)/2.55)
        let green = UInt8(Float(g)/2.55)
        let blue = UInt8(Float(b)/2.55)
        let command = RGBLedCommand(red: red, green: green, blue: blue)
        send(command: command)
    }
    
    public func readLightSensor(callback: ((Float) -> Void)? = nil) {
        lightIntensityCallback = callback
        let command = ReadLightSensorCommand()
        send(command: command)
    }
    
    public func getButtonState(callback: ((Bool, Bool, Bool) -> Void)? = nil) {
        buttonCallback = callback
        let command = GetButtonCommand()
        send(command: command)
    }
    
    public func readPotentiometer(callback: ((Float) -> Void)? = nil) {
        potentiometerCallback = callback
        let command = ReadPotentiometerCommand()
        send(command: command)
    }
    
    public func readSoundSensor(callback: ((Float) -> Void)? = nil) {
        soundIntensityCallback = callback
        let command = ReadSoundSensorCommand()
        send(command: command)
    }
    
    public func getGyro(callback: ((Float, Float, Float, Float, Float, Float) -> Void)? = nil) {
        gyroCallback = callback
        let command = GetGyroCommand()
        send(command: command)
    }
    
    public func getShake(callback: ((Bool) -> Void)? = nil) {
        shakeCallback = callback
        let command = GetShakeCommand()
        send(command: command)
    }
    
    public func readColorSensor(callback: ((ColorType) -> Void)? = nil) {
        colorCallback = callback
        let command = ReadColorSensorCommand()
        send(command: command)
    }
    
    public func hasObstacle(callback: ((Bool) -> Void)? = nil) {
        hasObstacleCallback = callback
        let command = HasObstacleCommand()
        send(command: command)
    }
    
    private func send(command: NeuronCommand) {
        sender?.send(data: command.data)
    }
}

extension Codey: NeuronDataParserDelegate {
    public func onParseData(_ data: Data) {
        interpreter.received(data: data)
    }
    
    public func onParseErrorData(_ data: Data) {
        debugPrint("onParseErrorData: \(data.hexString)")
    }
    
    public func onBufferOverflow(length: Int) {
        debugPrint("onBufferOverflow: \(length)")
    }
}

extension Codey: CodeyInterpreterDelegate {
    public func onReceive(color: ColorType) {
        colorCallback?(color)
    }
    
    public func onReceive(hasObstacle: Bool) {
        hasObstacleCallback?(hasObstacle)
    }
    
    public func onReceive(isShake: Bool) {
        shakeCallback?(isShake)
    }
    
    public func onReceive(roll: Float, pitch: Float, yaw: Float, accX: Float, accY: Float, accZ: Float) {
        gyroCallback?(roll, pitch, yaw, accX, accY, accZ)
    }
    
    public func onReceive(buttonAPressed: Bool, buttonBPressed: Bool, buttonCPressed: Bool) {
        buttonCallback?(buttonAPressed, buttonBPressed, buttonCPressed)
    }
    
    public func onReceive(lightIntensity: Float) {
        lightIntensityCallback?(lightIntensity)
    }
    
    public func onReceive(potentiometer: Float) {
        potentiometerCallback?(potentiometer)
    }
    
    public func onReceive(soundIntensity: Float) {
        soundIntensityCallback?(soundIntensity)
    }
}

public enum MusicType: String {
    case start
    case jump
    case wrong
    case laugh
    case sad
    case wake
    case beeps
    case warning
    case explosion
}

public enum FacePanelType: String {
    case angry = "00003c1e0e0400000000040e1e3c0000"
    case dizziness = "1c224a524c201c00001c204c524a221c"
    case happy = "000c18181c0c000000000c1c18180c00"
    case shock = "003c4242423c000000003c4242423c00"
}

public enum SoundNote: Int {
    case zero = 0, c2 = 65, d2 = 73, e2 = 82, f2 = 87, g2 = 98, a2 = 110, b2 = 123, c3 = 131, d3 = 147,
    e3 = 165, f3 = 175, f3m = 185, g3 = 196, g3m = 208, a3 = 220, b3 = 247, c4 = 262, c4m = 277,
    d4 = 294, d4m = 311, e4 = 330, f4 = 349, g4 = 392, g4m = 415, a4 = 440, a4m = 466, b4 = 494,
    c5 = 523, c5m = 554, d5 = 587, d5m = 622, e5 = 658, f5 = 698, g5 = 784, a5 = 880, b5 = 988,
    c6 = 1047, d6 = 1175, e6 = 1319, f6 = 1397, g6 = 1568, a6 = 1760, b6 = 1976, c7 = 2093, d7 = 2349,
    e7 = 2637, f7 = 2794, g7 = 3136, a7 = 3520, b7 = 3951, c8 = 4186
    init(intValue: Int) {
        self.init(rawValue: intValue)!
    }
}

public enum SoundBeat: Int {
    case whole = 1000
    case half = 500
    case quarter = 250
    case eighth = 125
    case sixteenth = 62
    init(intValue: Int) {
        self.init(rawValue: intValue)!
    }
}

public enum ColorType: Int {
    case unknown = -1
    case white = 0
    case purple = 1
    case red = 2
    case yellow = 4
    case green = 5
    case cyan = 6
    case blue = 7
    case pink = 8
    case black = 9
}
