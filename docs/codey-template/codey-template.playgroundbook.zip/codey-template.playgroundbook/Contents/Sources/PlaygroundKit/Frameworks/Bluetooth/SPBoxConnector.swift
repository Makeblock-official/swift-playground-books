//
//  SPBoxConnector.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit
import CoreBluetooth
import PlaygroundBluetooth

public class SPConnector: PlaygroundBluetoothConnectionViewDelegate, PlaygroundBluetoothConnectionViewDataSource {
    private let issueIcon = UIImage.init(named: "bluetooth") ?? UIImage()

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView,
                               shouldDisplayDiscovered peripheral: CBPeripheral,
                               withAdvertisementData advertisementData: [String: Any]?,
                               rssi: Double) -> Bool {
        let prefix = SPBLECenter.shared.isNeuron ? Makeblock.neuronPrefix : Makeblock.prefix
        guard rssi < 0.0 && rssi > -60.0,
            let name = peripheral.name,
            name.hasPrefix(prefix) else {
            return false
        }
        return true
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView,
                               shouldConnectTo peripheral: CBPeripheral,
                               withAdvertisementData advertisementData: [String: Any]?,
                               rssi: Double) -> Bool {
        return true
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, willDisconnectFrom peripheral: CBPeripheral) {
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, titleFor state: PlaygroundBluetoothConnectionView.State) -> String {
        switch state {
        case .noConnection:
            return NSLocalizedString("Connect Device", comment: "")
        case .connecting:
            return NSLocalizedString("Connecting", comment: "")
        case .searchingForPeripherals:
            return NSLocalizedString("Searching", comment: "")
        case .selectingPeripherals:
            return NSLocalizedString("Devices", comment: "")
        case .connectedPeripheralFirmwareOutOfDate:
            return NSLocalizedString("Timeout", comment: "")
        }
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, firmwareUpdateInstructionsFor peripheral: CBPeripheral) -> String {
        return ""
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView,
                               itemForPeripheral peripheral: CBPeripheral,
                               withAdvertisementData advertisementData: [String: Any]?) -> PlaygroundBluetoothConnectionView.Item {
        let name = peripheral.name?.peripheralDisplayName ?? "Makeblock"
        return PlaygroundBluetoothConnectionView.Item(name: name, icon: issueIcon, issueIcon: issueIcon, firmwareStatus: .upToDate)
    }
}

extension String {
    public var peripheralDisplayName: String {
        let nameLowercase = lowercased()
        if nameLowercase.hasPrefix("makeblock") {
            if nameLowercase == "makeblock" || nameLowercase == "makeblock_le" {
                return "Makeblock"
            } else {
                let replacingMakeblock_LE = replacingOccurrences(of: "Makeblock_LE", with: "")
                let result = replacingMakeblock_LE.replacingOccurrences(of: "Makeblock_", with: "")
                return result
            }
        } else if nameLowercase.hasPrefix("neuron") {
            let result = replacingOccurrences(of: "Neuron_", with: "")
            return result
        }
        return "Makeblock"
    }
}
