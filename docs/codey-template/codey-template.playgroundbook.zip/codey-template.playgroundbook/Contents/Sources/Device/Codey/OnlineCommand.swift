//
//  OnlineCommand.swift
//  Codey
//
//  Created by 彭康政 on 2018/02/08.
//

import Foundation

public struct MoveCommand: NeuronCommand {
    var directionLeft: UInt8
    var leftSpeed: UInt8
    var directionRight: UInt8
    var rightSpeed: UInt8
    
    public var blockNo: UInt8 { return 0x02 }
    
    public var type: UInt8? { return 0x63 }
    
    public var subType: UInt8? { return 0x10 }
    
    public var commandID: UInt8? { return 0x11 }
    
    public var payload: [UInt8]? {
        return [directionLeft, leftSpeed, directionRight, rightSpeed]
    }
    
    public init(left: Int, right: Int) {
        self.directionLeft = left > 0 ? 0x00 : 0x01
        self.directionRight = right > 0 ? 0x00 : 0x01
        self.leftSpeed = abs(left) > 100 ? 100 : UInt8(abs(left))
        self.rightSpeed = abs(right) > 100 ? 100 : UInt8(abs(right))
    }
}

public struct SoundCommand: NeuronCommand {
    var name: [UInt8]
    
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x47 }
    
    public var payload: [UInt8]? {
        return  [UInt8(name.count)] + name
    }
    
    public init(fileName: String) {
        self.name = fileName.bytes
    }
}

public struct SoundNoteCommand: NeuronCommand {
    let note: SoundNote
    let beat: SoundBeat
    
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x48 }
    
    public var payload: [UInt8]? {
        var datum: [UInt8] = []
        let noteValue = NeuronDataEncoder.encodeValue(note.rawValue, type: .long)
        datum.append(contentsOf: noteValue)
        let beatValue = NeuronDataEncoder.encodeValue(beat.rawValue, type: .long)
        datum.append(contentsOf: beatValue)
        return datum
    }
    
    public init(note: SoundNote, beat: SoundBeat) {
        self.note = note
        self.beat = beat
    }
}

public struct FacePanelCommand: NeuronCommand {
    let array: [UInt8]

    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x42 }
    
    public var payload: [UInt8]? { return array }
    
    public init(hexStr: String) {
        if let hexArray = [UInt8].bytes(fromHexString: hexStr) {
            self.array = hexArray.flatMap { DataConverter.convert8to7bit([$0])}
        } else {
            self.array = []
        }
    }
}

public struct RGBLedCommand: NeuronCommand {
    let redValue: UInt8
    let greenValue: UInt8
    let blueValue: UInt8
    
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x41 }
    
    public var payload: [UInt8]? {
        return [redValue, greenValue, blueValue]
    }
    
    public init(red: UInt8, green: UInt8, blue: UInt8) {
        self.redValue = red > 100 ? 100 : red
        self.greenValue = green > 100 ? 100 : green
        self.blueValue = blue > 100 ? 100 : blue
    }
}

public struct FacePanelPixelCommand: NeuronCommand {
    let x: UInt8
    let y: UInt8
    let isOn: UInt8
    
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x45 }
    
    public var payload: [UInt8]? {
        return [x, y, isOn]
    }
    
    public init(x: Int, y: Int, isOn: Bool) {
        self.x = UInt8(x)
        self.y = UInt8(y)
        self.isOn = isOn ? 0x01 : 0x00
    }
}

public struct ClearFacePanelCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x44 }
    
    public init() {}
}

public struct GetButtonCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x01 }
    
    public init() {}
}

public struct ReadLightSensorCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x02 }
    
    public init() {}
}

public struct ReadSoundSensorCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x03 }
    
    public init() {}
}

public struct ReadPotentiometerCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x04 }
    
    public init() {}
}

public struct GetGyroCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x05 }
    
    public init() {}
}

public struct GetShakeCommand: NeuronCommand {
    public var type: UInt8? { return 0x67 }
    
    public var subType: UInt8? { return 0x01 }
    
    public var commandID: UInt8? { return 0x08 }
    
    public init() {}
}

public struct ReadColorSensorCommand: NeuronCommand {
    public var blockNo: UInt8 { return 0x02 }
    
    public var type: UInt8? { return 0x63 }
    
    public var subType: UInt8? { return 0x10 }
    
    public var commandID: UInt8? { return 0x02 }
    
    public init() {
    }
}

public struct HasObstacleCommand: NeuronCommand {
    public var blockNo: UInt8 { return 0x02 }
    
    public var type: UInt8? { return 0x63 }
    
    public var subType: UInt8? { return 0x10 }
    
    public var commandID: UInt8? { return 0x08 }
    
    public init() {
    }
}
