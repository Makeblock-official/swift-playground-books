//
//  LiveViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import PlaygroundBluetooth

public class TemplateViewController: LiveViewController {
    fileprivate let bgView = UIImageView(image: UIImage(named: "main-bg-disconnected"))
    fileprivate let robotView = UIImageView(image: UIImage(named: "codey-disconnected"))
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)
    
    private var tiltDetector = TiltDetector()
    
    // MARK: LifeCycle
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupBgView()
        setupRobotView()
        setBackgroundAudio(visible: false)
        tiltDetector.delegate = self
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tiltDetector.start()
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tiltDetector.stop()
    }
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateBgContentMode()
    }
    
    public override func didDisconnect() {
        bgView.image = UIImage(named: "main-bg-disconnected")
        robotView.image = UIImage(named: "codey-disconnected")
    }
    
    public override func didPrepared() {
        Loader.currentBot.changeToOnline()
        
        bgView.image = UIImage(named: "main-bg-connected")
        robotView.image = UIImage(named: "codey-connected")
    }
    
    public override func onStopRunning() {
        Loader.currentBot.setDCMotor(leftSpeed: 0, rightSpeed: 0)
        Loader.currentBot.setLEDLight(r: 0, g: 0, b: 0)
    }
    
    public override func didReceive(data: Data) {
        Loader.currentBot.didReceive(data: data)
    }
    
    // MARK: Private Methods
    
    private func setupBgView() {
        view.addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }
    
    private func setupRobotView() {
        robotView.contentMode = .scaleAspectFit
        view.addSubview(robotView)
        robotView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view)
            make.bottom.equalTo(self.view)
            make.width.equalTo(self.view)
            make.height.equalTo(robotView.snp.width).multipliedBy(0.427)
        }
    }
    
    private func updateBgContentMode() {
        let screenMode = getScreenMode(frame: view.frame)
        switch screenMode {
        case .hHalf:
            bgView.contentMode = .scaleAspectFit
        default:
            bgView.contentMode = .topLeft
        }
    }
}

extension TemplateViewController: TiltDetectorDelegate {
    public func onTiltUpdate(left: Bool, right: Bool, forword: Bool, backword: Bool) {
        sendToContentsWithEnum(.iPadTiltedForward(forword))
        sendToContentsWithEnum(.iPadTiltedBackward(backword))
        sendToContentsWithEnum(.iPadTiltedLeft(left))
        sendToContentsWithEnum(.iPadTiltedRight(right))
    }
}
