//
//  SPBoxConnector.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit
import CoreBluetooth
import PlaygroundBluetooth

public class SPConnector: PlaygroundBluetoothConnectionViewDelegate, PlaygroundBluetoothConnectionViewDataSource {
    private let issueIcon = UIImage.init(named: "bluetooth") ?? UIImage()

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView,
                               shouldDisplayDiscovered peripheral: CBPeripheral,
                               withAdvertisementData advertisementData: [String: Any]?,
                               rssi: Double) -> Bool {
        guard rssi < 0.0 && rssi > -60.0 else { return false }
        guard let name = peripheral.name, name.hasPrefix(Makeblock.prefix) else { return false }
        return true
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView,
                               shouldConnectTo peripheral: CBPeripheral,
                               withAdvertisementData advertisementData: [String: Any]?,
                               rssi: Double) -> Bool {
        return true
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, willDisconnectFrom peripheral: CBPeripheral) {
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, titleFor state: PlaygroundBluetoothConnectionView.State) -> String {
        switch state {
        case .noConnection:
            return NSLocalizedString("Connect Device", comment: "")
        case .connecting:
            return NSLocalizedString("Connecting", comment: "")
        case .searchingForPeripherals:
            return NSLocalizedString("Searching", comment: "")
        case .selectingPeripherals:
            return NSLocalizedString("Devices", comment: "")
        case .connectedPeripheralFirmwareOutOfDate:
            return NSLocalizedString("Timeout", comment: "")
        }
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView, firmwareUpdateInstructionsFor peripheral: CBPeripheral) -> String {
        return ""
    }

    public func connectionView(_ connectionView: PlaygroundBluetoothConnectionView,
                               itemForPeripheral peripheral: CBPeripheral,
                               withAdvertisementData advertisementData: [String: Any]?) -> PlaygroundBluetoothConnectionView.Item {
        let name = peripheral.name ?? "none"
        return PlaygroundBluetoothConnectionView.Item(name: name, icon: issueIcon, issueIcon: issueIcon, firmwareStatus: .upToDate)
    }
}
