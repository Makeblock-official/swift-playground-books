//
//  PlaygroundHelpers.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundSupport
import UIKit

public let sharedTaskMgr: SPTaskManager<MCommand> = SPTaskManager<MCommand>()

public var currentProxy: PlaygroundRemoteLiveViewProxy? {
    return PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
}

public func log(_ text: String, _ index: Int = 0) {
    currentLiveViewController?.log(text)
}

public func setProxyDelegate(_ delegate: PlaygroundRemoteLiveViewProxyDelegate) {
    if let proxy = currentProxy {
        proxy.delegate = delegate
    }
}

public func sendToLiveView(_ value: PlaygroundValue) {
    if let proxy = currentProxy {
        proxy.send(value)
    }
}

public func sendToContents(_ value: PlaygroundValue) {
    if let proxy = PlaygroundPage.current.liveView as? PlaygroundLiveViewMessageHandler {
        proxy.send(value)
    }
}

public func sendToContentsWithEnum(_ enumValue: SPCallbackCommand) {
    sendToContents(enumValue.value)
}

public func instantiateLiveView() -> PlaygroundLiveViewable {
    let liveViewController = LiveViewController()
    return liveViewController
}

public var currentLiveViewController: LiveViewController? {
    if let vc = PlaygroundPage.current.liveView as? LiveViewController {
        return vc
    }
    return nil
}
