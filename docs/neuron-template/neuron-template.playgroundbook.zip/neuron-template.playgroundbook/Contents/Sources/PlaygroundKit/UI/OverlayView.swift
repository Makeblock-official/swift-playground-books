//
//  OverlayView.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/7/11.
//

import Foundation
import UIKit

public class OverlayView: UIView {

    init() {
        let blurEffect = UIBlurEffect(style: .extraLight)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.layer.cornerRadius = 22
        blurEffectView.clipsToBounds = true
        blurEffectView.translatesAutoresizingMaskIntoConstraints = true
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        super.init(frame: CGRect.zero)

        addSubview(blurEffectView)
        blurEffectView.frame = bounds

        let whiteOverBlurView = UIView()
        whiteOverBlurView.translatesAutoresizingMaskIntoConstraints = true
        whiteOverBlurView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(whiteOverBlurView)
        whiteOverBlurView.frame = bounds
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
