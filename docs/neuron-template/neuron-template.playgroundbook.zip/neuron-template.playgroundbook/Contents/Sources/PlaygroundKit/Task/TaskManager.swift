//
//  TaskManager.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/8/6.
//

import Foundation
import PlaygroundSupport
import UIKit

public protocol TaskManagerDelegate: class {
    func manager<Command: SPCommand>(didPerformTask: SPTask<Command>)
}

public final class TaskManager<Command: SPCommand> {
    var currentIndex = 0
    public var delegate: TaskManagerDelegate?
    var tasks: [SPTask<Command>] = []
    var time: TimeInterval = -1
    
    public init(delegate: TaskManagerDelegate? = nil) {
        self.delegate = delegate
    }
    
    public func addTasks(_ tasks: [SPTask<Command>]) {
        self.tasks.append(contentsOf: tasks)
        sendTasks()
    }
    
    public func sendTasks() {
        if let proxy = Loader.currentProxy {
            guard tasks.count > 0 else {
                return
            }
            let arrayValue = tasks.map { (task) -> PlaygroundValue in
                return task.value
            }
            proxy.send(.array(arrayValue))
            
            let time = tasks.reduce(0, { (r, ele) -> Float in
                return Float(r) + ele.duration
            })
            usleep(UInt32(time * 1e6))
            tasks.removeAll()
        }
    }
}
