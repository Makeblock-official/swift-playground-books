import PlaygroundSupport
import Foundation

public class RuleManager {
    
    public init() {}
    public var commands: [CodeCommand] = []
    fileprivate var rule: CodeRule = CodeRule()
    fileprivate var shouldCheck = true
    
    public func registerRule(_ rule: CodeRule) {
        self.rule = rule
    }
    
    public func addCommand(_ command: CodeCommand) {
        if commands.contains(command) {
            
        } else {
            commands.append(command)
        }
    }
    
    public func checkTaskState() {
        if !shouldCheck {
            return
        }
        var result = true
        for (index, value) in rule.commands.enumerated() {
            if index >= commands.count {
                result = false
                break
            } else {
                if value != commands[index] {
                    result = false
                    break
                }
            }
        }
        var message = ""
        if result || rule.count == 0 || commands.count >= rule.count {
            message = NSLocalizedString("CompleteMessageKey", comment: "Success message")
            shouldCheck = false
        } else {
            message = "请调试你的程序！"
        }
        PlaygroundPage.current.assessmentStatus = .pass(message: message)
    }
}

public enum CodeCommand {
    case getLight
    case playSound
    case showLEDPanel
    case showLEDBand
}

public class CodeRule {
    public init() {
        
    }
    public var count = -1
    public var commands: [CodeCommand] = []
}
