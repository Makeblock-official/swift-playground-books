//
//  ContentListenr.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundSupport

public typealias FloatCallback = ((Float) -> Void)
public typealias BoolCallback = ((Bool) -> Void)
public typealias IntCallback = ((Int) -> Void)

public class ContentListenr: PlaygroundRemoteLiveViewProxyDelegate {
    public init() {}

    public var gyroXangle: Int = -99
    public var gyroYangle: Int = -99
    public var gyroZangle: Int = -99
    
    public var getSoilmoisture: Int = -99
    public var getLight: Int = -99 
    public var getDistance: Int = -99
    public var getVoice: Int = -99
    public var getTemperature: Int = -99
    public var getKnob: Int = -99
    
    public var blueTouched: Bool = false
    public var yellowTouched: Bool = false
    public var redTouched: Bool = false
    public var greenTouched: Bool = false
    
    public var light: Float = -99
    public var lineSign: Int = -99
    public var ultrasonic: Float = -99
    public var isConnected: Bool = false
    
    public var iPadTiltedForward: Bool = false
    public var iPadTiltedBackward: Bool = false
    public var iPadTiltedLeft: Bool = false
    public var iPadTiltedRight: Bool = false
    
    public var ultrasonicCallBack: FloatCallback?
    public var lightCallBack: FloatCallback?
    public var isConnectedCallBack: BoolCallback?
    public var lineSignCallBack: IntCallback?
    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {

        guard let cmdValue = SPCallbackCommand.init(message) else {
            return
        }
        switch cmdValue {
        case .gyroXangle(let value):
            self.gyroXangle = value
        case .gyroYangle(let value):
            self.gyroYangle = value
        case .gyroZangle(let value):
            self.gyroZangle = value
        case .getSoilmoisture(let value):
            self.getSoilmoisture = value
        case .getLight(let value):
            self.getLight = value
        case .getDistance(let value):
            self.getDistance = value
        case .getVoice(let value):
            self.getVoice = value
        case .getTemperature(let value):
            self.getTemperature = value
        case .getKnob(let value):
            self.getKnob = value
        case .blueTouched(let value):
            self.blueTouched = value
        case .yellowTouched(let value):
            self.yellowTouched = value
        case .redTouched(let value):
            self.redTouched = value
        case .greenTouched(let value):
            self.greenTouched = value
        case .iPadTiltedForward(let value):
            self.iPadTiltedForward = value
        case .iPadTiltedBackward(let value):
            self.iPadTiltedBackward = value
        case .iPadTiltedLeft(let value):
            self.iPadTiltedLeft = value
        case .iPadTiltedRight(let value):
            self.iPadTiltedRight = value
        default:
            break
        }
    }
    
    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
        PlaygroundPage.current.finishExecution()
    }

}
