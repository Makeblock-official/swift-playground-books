//
//  ActionTool
//  Neuron
//
//  Created by CatchZeng on 2018/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

extension ActionTool {    
    static public func powerOn() {
        sendAction(.powerOn, duration: 0.5)
    }
    
    static public func powerOff() {
        sendAction(.powerOff)
    }
    
    static public func getKnob() {
        sendAction(.getKnob)
    }
    
    static public func getLight() {
        sendAction(.getLight)
    }
    
    static public func getTemperature() {
        sendAction(.getTemperature)
    }
    
    static public func getDistance() {
        sendAction(.getDistance)
    }
    
    static public func getFunnyTouch() {
        sendAction(.getFunnyTouch)
    }
    
    static public func changeLightIntensity(_ light: Float) {
        sendAction(.lightSensor(lightIntensity: light), duration: ActionTool.DefaultDuration)
    }

    static public func playSound(note: SoundNote, beat: SoundBeat) {
        sendAction(.sound(note: note, beat: beat), duration: ActionTool.DefaultDuration)
    }
    
    static public func dcMotor(slot: DCMotorSlot, power: Int) {
        sendAction(.dcMotor(slot: slot, power: power), duration: ActionTool.DefaultDuration)
    }
    
    static public func dcMotor(power1: Int, power2: Int) {
        sendAction(.dcMotorMeanwhile(power1: power1, power2: power2), duration: ActionTool.DefaultDuration)
    }
    
    static public func ledColor(color: LEDColor, style: LEDStyle) {
        sendAction(.ledBand(color: color, style: style), duration: ActionTool.DefaultDuration)
    }
    
    static public func panelShow(expression: Expression) {
        sendAction(.ledPanel(expression: expression), duration: ActionTool.DefaultDuration)
    }
    
    static public func panelColor(r: Int, g: Int, b: Int) {
        sendAction(.panelColor(r: r, g: g, b: b), duration: ActionTool.DefaultDuration)
    }
    
    static public func setServo(port: ServoPort, angle: Int) {
        sendAction(.servo(port: port, angle: angle), duration: 1)
    }
    
    static public func turnLED(x: Int, y: Int, r: Int, g: Int, b: Int) {
        sendAction(.led(x: x, y: y, r: r, g: g, b: b), duration: ActionTool.DefaultDuration)
    }
    
    static public func distance(_ height: Int) {
        sendAction(.distanceSensor(distance: height), duration: ActionTool.DefaultDuration)
    }
    
    static public func iPadSound(note: PadSoundNote) {
        sendAction(.iPadSound(note: note), duration: ActionTool.DefaultDuration)
    }
    
    static public func stopiPadSound() {
        sendAction(.stopiPadSound, duration: ActionTool.DefaultDuration)
    }
}
