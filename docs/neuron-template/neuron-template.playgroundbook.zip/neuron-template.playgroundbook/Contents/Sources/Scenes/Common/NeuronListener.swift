//
//  NeuronListener
//  Neuron
//
//  Created by CatchZeng on 2018/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

public class NeuronListener: BlockContainerDelegate, NeuronPackageInterpreterDelegate {
    
    public func onReceive(gyroSensorPackage: GyroSensorPackage) {
        switch gyroSensorPackage.dataType {
        case .xAngle:
            sendToContentsWithEnum(.gyroXangle(gyroSensorPackage.value))
        case .yAngle:
            sendToContentsWithEnum(.gyroYangle(gyroSensorPackage.value))
        case .zAngle:
            sendToContentsWithEnum(.gyroZangle(gyroSensorPackage.value))
        default:
            break
        }
    }
    
    public func onReceive(funnyTouchPackage: FunnyTouchPackage) {
        sendToContentsWithEnum(.blueTouched(funnyTouchPackage.blueTouched))
        sendToContentsWithEnum(.greenTouched(funnyTouchPackage.greenTouched))
        sendToContentsWithEnum(.redTouched(funnyTouchPackage.redTouched))
        sendToContentsWithEnum(.yellowTouched(funnyTouchPackage.yellowTouched))
        
        let blue = funnyTouchPackage.blueTouched ? 1 : 0
        let green = funnyTouchPackage.greenTouched ? 1 : 0
        let red = funnyTouchPackage.redTouched ? 1 : 0
        let yellow = funnyTouchPackage.yellowTouched ? 1 : 0
        let blockWithValue = BlockWithValue(block: .funnyTouch, value: [green, red, yellow, blue])
        Loader.currentLiveViewController?.receive(blockWithValue: blockWithValue)
    }
    
    public func onReceive(knobPackage: KnobPackage) {
        sendToContentsWithEnum(.getKnob(knobPackage.value))
        
        let blockWithValue = BlockWithValue(block: .knob, value: [knobPackage.value])
        Loader.currentLiveViewController?.receive(blockWithValue: blockWithValue)
    }
    
    public func onReceive(temperaturePackage: TemperaturePackage) {
        sendToContentsWithEnum(.getTemperature(temperaturePackage.value))
        
        let blockWithValue = BlockWithValue(block: .temperature, value: [temperaturePackage.value])
        Loader.currentLiveViewController?.receive(blockWithValue: blockWithValue)
    }
    
    public func onReceive(lightPackage: LightPackage) {
        sendToContentsWithEnum(.getLight(lightPackage.value))
        
        let blockWithValue = BlockWithValue(block: .light, value: [lightPackage.value])
        Loader.currentLiveViewController?.receive(blockWithValue: blockWithValue)
    }
    
    public func onReceive(distancePackage: DistancePackage) {
        sendToContentsWithEnum(.getDistance(distancePackage.value))
        
        let blockWithValue = BlockWithValue(block: .distance, value: [distancePackage.value])
        Loader.currentLiveViewController?.receive(blockWithValue: blockWithValue)
    }
    
    public func onReceive(voicePackage: VoicePackage) {
        sendToContentsWithEnum(.getVoice(voicePackage.value))
    }
    
    public func onReceive(soilMoisturePackage: SoilMoisturePackage) {
       sendToContentsWithEnum(.getSoilmoisture(soilMoisturePackage.value))
    }
    
    public func onReceive(unkonwnPackage: Data) {
    }
    
    public func didConnect(block: BlockType, on position: Int) {
        switch block {
        case .light:
            Loader.currentBot.getLight()
        case .distance:
            Loader.currentBot.getDistance()
        case .gyro:
            Loader.currentBot.subscribeGyroData(dataType: .xAngle, way: .onChange, timeIntervalInMs: 500)
            Loader.currentBot.subscribeGyroData(dataType: .yAngle, way: .onChange, timeIntervalInMs: 500)
            Loader.currentBot.subscribeGyroData(dataType: .zAngle, way: .onChange, timeIntervalInMs: 500)
        case .temperature:
            Loader.currentBot.getTemperature()
        case .funnyTouch:
            Loader.currentBot.getFunnyTouch()
        case .knob:
            Loader.currentBot.getKnob()
        default:
            break
        }
        
        Loader.currentLiveViewController?.connect(block: block, position: position)
    }
    
    public func didDisConnect(block: BlockType, on position: Int) {
        Loader.currentLiveViewController?.disConnect(block: block, position: position)
    }
}
