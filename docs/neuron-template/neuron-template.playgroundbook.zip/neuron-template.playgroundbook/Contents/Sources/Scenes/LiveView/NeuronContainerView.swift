//
//  NeuronContainerView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/8.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import UIKit

class NeuronContainerView: UIView {
    private var tableView: UITableView!
    private var blocks = [BlockWithValue]()
    private var isAdding = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    public func reload(blocks: [BlockWithValue]) {
        self.blocks = blocks
        tableView.reloadData()
    }
    
    public func add(block: BlockWithValue) {
        var indexPaths = [IndexPath]()
        let indexPath = IndexPath(row: blocks.count, section: 0)
        indexPaths.append(indexPath)
        
        blocks.append(block)
        
        self.isAdding = true
        
        tableView.beginUpdates()
        tableView.insertRows(at: indexPaths, with: .automatic)
        tableView.endUpdates()
        
        GCDDelay.delay(0.5) { [weak self] in
            self?.isAdding = false
        }
    }
    
    public func remove(block: BlockType) {
        let count = blocks.count
        for i in 0..<count {
            let blockWithValue = blocks[count-i-1]
            if blockWithValue.block == block {
                blocks.remove(at: count-i-1)
                break
            }
        }
        
        tableView.reloadData()
    }
    
    public func update(block: BlockWithValue) {
        var row = -1
        let count = blocks.count
        for i in 0..<count {
            let index = count-i-1
            var blockWithValue = blocks[index]
            if blockWithValue.block == block.block {
                if blockWithValue.value != block.value {
                    blockWithValue.value = block.value
                    blocks[index] = blockWithValue
                    row = index
                }
                break
            }
        }
        
        if row == -1 {
            return
        }
        
        var indexPaths = [IndexPath]()
        let indexPath = IndexPath(row: row, section: 0)
        indexPaths.append(indexPath)
        
        if isAdding {
            GCDDelay.delay(0.5) { [weak self] in
                self?.tableView.reloadRows(at: indexPaths, with: .none)
            }
        } else {
            tableView.reloadRows(at: indexPaths, with: .none)
        }
    }
    
    private func commonInit() {
        tableView = UITableView(frame: CGRect.zero)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = .none
        tableView.tableFooterView = UIView()
        self.addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.width.equalTo(460)
            make.bottom.equalTo(self)
            make.top.equalTo(130)
            make.centerX.equalTo(self)
        }
    }
}

extension NeuronContainerView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return blocks.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let blockWithValue = blocks[indexPath.row]
        let block = blockWithValue.block
        let value = blockWithValue.value
        
        if blockWithValue.block == .funnyTouch {
            if let cell = tableView.dequeueReusableCell(withIdentifier: NeuronFunnyTouchCell.identifier) as? NeuronFunnyTouchCell {
                cell.config(block: block, value: value)
                return cell
            } else {
                let cell = NeuronFunnyTouchCell(style: .default, reuseIdentifier: NeuronFunnyTouchCell.identifier)
                cell.config(block: block, value: value)
                return cell
            }
        } else {
            if let cell = tableView.dequeueReusableCell(withIdentifier: NeuronNumberCell.identifier) as? NeuronNumberCell {
                cell.config(block: block, value: value.first)
                return cell
            } else {
                let cell = NeuronNumberCell(style: .default, reuseIdentifier: NeuronNumberCell.identifier)
                cell.config(block: block, value: value.first)
                return cell
            }
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
