//
//  NeuronCell.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/8.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import UIKit

class NeuronNumberCell: UITableViewCell {
    static let identifier = "NeuronNumberCell"
    private var containerView: UIView!
    private var iconView: UIImageView!
    private var nameLabel: UILabel!
    private var numberBg: RoundedCornerView!
    private var numLabel: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        commonInit()
    }
    
    public func config(block: BlockType, value: Int?) {
        nameLabel.text = block.name
        iconView.image = block.icon
        if let value = value {
            numLabel.text = "\(value)"
        } else {
            numLabel.text = "0"
        }
    }
    
    private func commonInit() {
        backgroundColor = UIColor.clear
        selectionStyle = .none
        setupContainerView()
        setupIconView()
        setupNameLabel()
        setupNumberBg()
        setupNumLabel()
    }
    
    private func setupContainerView() {
        containerView = UIView(frame: CGRect.zero)
        containerView.backgroundColor = UIColor.white
        containerView.cornerRadius = 5
        addSubview(containerView)
        
        containerView.snp.makeConstraints { (make) in
            make.width.top.centerX.equalTo(self)
            make.height.equalTo(self).multipliedBy(0.8)
        }
    }
    
    private func setupIconView() {
        iconView = UIImageView(image: UIImage(named: "neuron-light-sensor"))
        iconView.contentMode = .scaleAspectFit
        containerView.addSubview(iconView)
        
        iconView.snp.makeConstraints { (make) in
            make.height.equalTo(containerView).multipliedBy(0.7)
            make.width.equalTo(iconView.snp.height)
            make.left.equalTo(containerView).offset(20)
            make.centerY.equalTo(containerView)
        }
    }
    
    private func setupNameLabel() {
        nameLabel = UILabel(frame: CGRect.zero)
        nameLabel.text = "Light Sensor"
        nameLabel.font = UIFont.systemFont(ofSize: 20)
        nameLabel.textColor = UIColor(red: 0.39, green: 0.39, blue: 0.39, alpha: 1.0)
        containerView.addSubview(nameLabel)
        
        nameLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(containerView)
            make.leading.equalTo(iconView.snp.trailing).offset(20)
        }
    }
    
    private func setupNumberBg() {
        numberBg = RoundedCornerView(frame: CGRect.zero)
        numberBg.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.0)
        containerView.addSubview(numberBg)
        
        numberBg.snp.makeConstraints { (make) in
            make.centerY.equalTo(containerView)
            make.height.equalTo(containerView).multipliedBy(0.6)
            make.width.equalTo(numberBg.snp.height)
            make.trailing.equalTo(containerView.snp.trailing).offset(-20)
        }
    }
    
    private func setupNumLabel() {
        numLabel = UILabel(frame: CGRect.zero)
        numLabel.text = "57"
        numLabel.font = UIFont.boldSystemFont(ofSize: 25)
        numLabel.textColor = UIColor(red: 1.0, green: 75/255.0, blue: 38/255.0, alpha: 1.0)
        numberBg.addSubview(numLabel)
        
        numLabel.snp.makeConstraints { (make) in
            make.center.equalTo(numberBg)
        }
    }
}
