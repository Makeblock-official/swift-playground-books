//
//  NeuronCommands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public enum DataReportWay: UInt8 {
    case query = 0x00
    case onChange = 0x01
    case cyclicity = 0x02
}

public enum GyroDataType: UInt8 {
    case unknown = 0x00

    case shake = 0x01

    case xAccelerated = 0x02
    case yAccelerated = 0x03
    case zAccelerated = 0x04

    case xAngular = 0x05
    case yAngular = 0x06
    case zAngular = 0x07

    case xAngle = 0x08
    case yAngle = 0x09
    case zAngle = 0x0a
}

public struct DataReportWayCommand: NeuronCommand {
    private var block: BlockType
    private var way: DataReportWay
    private var timeInterval: Float

    public init (block: BlockType, way: DataReportWay, timeIntervalInMs: Float) {
        self.block = block
        self.way = way
        self.timeInterval = timeIntervalInMs
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? {
        // subType为空时，让type为空使得到的为空的数据
        if subType == nil {
            return nil
        }

        return block.typeCode
    }

    public var subType: UInt8? {
        return block.subTypeCode
    }

    public var commandID: UInt8? { return 0x7f }

    public var payload: [UInt8]? {
        var datum: [UInt8] = [way.rawValue]

        var data: [UInt8]
        if way == .cyclicity {
            data = NeuronDataEncoder.encodeValue(timeInterval, type: .long)
        } else {
            data = NeuronDataEncoder.encodeValue(0, type: .long)
        }
        datum.append(contentsOf: data)

        return datum
    }
}

public struct SubscribeGyroDataCommand: NeuronCommand {
    private var dataType: GyroDataType
    private var way: DataReportWay
    private var timeInterval: Float

    public init (dataType: GyroDataType, way: DataReportWay, timeIntervalInMs: Float) {
        self.dataType = dataType
        self.way = way
        self.timeInterval = timeIntervalInMs
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.sensor.rawValue  }

    public var subType: UInt8? { return BlockType.gyro.subTypeCode }

    public var commandID: UInt8? { return 0x01 }

    public var payload: [UInt8]? {
        var datum: [UInt8] = [way.rawValue, dataType.rawValue]

        var data: [UInt8]
        if way == .cyclicity {
            data = NeuronDataEncoder.encodeValue(timeInterval, type: .long)
        } else {
            data = NeuronDataEncoder.encodeValue(0, type: .long)
        }
        datum.append(contentsOf: data)

        return datum
    }
}

public struct CancelSubscribeGyroDataCommand: NeuronCommand {
    private var dataType: GyroDataType

    public init (dataType: GyroDataType) {
        self.dataType = dataType
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.sensor.rawValue  }

    public var subType: UInt8? { return BlockType.gyro.subTypeCode }

    public var commandID: UInt8? { return 0x02 }

    public var payload: [UInt8]? {
        return  [dataType.rawValue]
    }
}

public enum SoundNote: Int {
    case zero = 0, c2 = 65, d2 = 73, e2 = 82, f2 = 87, g2 = 98, a2 = 110, b2 = 123, c3 = 131, d3 = 147,
    e3 = 165, f3 = 175, f3m = 185, g3 = 196, g3m = 208, a3 = 220, b3 = 247, c4 = 262, c4m = 277,
    d4 = 294, d4m = 311, e4 = 330, f4 = 349, g4 = 392, g4m = 415, a4 = 440, a4m = 466, b4 = 494,
    c5 = 523, c5m = 554, d5 = 587, d5m = 622, e5 = 658, f5 = 698, g5 = 784, a5 = 880, b5 = 988,
    c6 = 1047, d6 = 1175, e6 = 1319, f6 = 1397, g6 = 1568, a6 = 1760, b6 = 1976, c7 = 2093, d7 = 2349,
    e7 = 2637, f7 = 2794, g7 = 3136, a7 = 3520, b7 = 3951, c8 = 4186
    init(intValue: Int) {
        self.init(rawValue: intValue)!
    }
}

public enum SoundBeat: Int {
    case whole = 1000
    case half = 500
    case quarter = 250
    case eighth = 125
    case sixteenth = 62
    init(intValue: Int) {
        self.init(rawValue: intValue)!
    }
}

public struct BuzzerCommand: NeuronCommand {
    private var pitch: SoundNote
    private var volume: Int

    public init (pitch: SoundNote, volume: Int) {
        self.pitch = pitch
        self.volume = volume
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.sound.rawValue }

    public var subType: UInt8? { return BlockType.buzzer.subTypeCode }

    public var commandID: UInt8? { return 0x01 }

    public var payload: [UInt8]? {
        var datum: [UInt8] = []
        let data = NeuronDataEncoder.encodeValue(pitch.rawValue, type: .short)
        datum.append(contentsOf: data)
        datum.append(UInt8(volume))
        return datum
    }
}

public enum ServoPort: UInt8 {
    case port1 = 0x01
    case port2 = 0x02
}

private func limitServo(angle: Int) -> Int {
    var finalAngle = angle
    if angle < 0 {
        finalAngle = 0
    } else if angle > 180 {
        finalAngle = 180
    }
    return finalAngle
}

public struct ServoCommand: NeuronCommand {
    private var angle: Int
    private var port: ServoPort

    public init (port: ServoPort, angle: Int) {
        self.port = port
        self.angle = limitServo(angle: angle)
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.move.rawValue }

    public var subType: UInt8? { return BlockType.servo.subTypeCode }

    public var payload: [UInt8]? {
        var datum: [UInt8] = [port.rawValue]
        let data = NeuronDataEncoder.encodeValue(angle, type: .SHORT)
        datum.append(contentsOf: data)
        return datum
    }
}

public enum DCMotorSlot: UInt8 {
    case slot1 = 0x02
    case slot2 = 0x03
}

private func limitDCMotor(speed: Int) -> Int {
    var finalSpeed = speed
    if speed < -100 {
        finalSpeed = -100
    } else if speed > 100 {
        finalSpeed = 100
    }
    return finalSpeed
}

public struct DCMotorCommand: NeuronCommand {
    private var speed: Int
    private var slot: DCMotorSlot

    public init (slot: DCMotorSlot, speed: Int) {
        self.slot = slot
        self.speed = limitDCMotor(speed: speed)
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.move.rawValue }

    public var subType: UInt8? { return BlockType.dcmotor.subTypeCode }

    public var payload: [UInt8]? {
        var datum: [UInt8] = [slot.rawValue]
        let data = NeuronDataEncoder.encodeValue(speed, type: .SHORT)
        datum.append(contentsOf: data)
        return datum
    }
}

public struct BothDCMotorCommand: NeuronCommand {
    private var speed1: Int
    private var speed2: Int

    public init (speed1: Int, speed2: Int) {
        self.speed1 = limitDCMotor(speed: speed1)
        self.speed2 = limitDCMotor(speed: speed2)
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.move.rawValue }

    public var subType: UInt8? { return BlockType.dcmotor.subTypeCode }

    public var payload: [UInt8]? {
        var datum: [UInt8] = [0x01]
        let data1 = NeuronDataEncoder.encodeValue(speed1, type: .SHORT)
        let data2 = NeuronDataEncoder.encodeValue(speed2, type: .SHORT)
        datum.append(contentsOf: data1)
        datum.append(contentsOf: data2)
        return datum
    }
}

public struct RGBLEDCommand: NeuronCommand {
    private var x: Int
    private var y: Int

    private var red: Int
    private var green: Int
    private var blue: Int

    public init (x: Int,
                 y: Int,
                 red: Int,
                 green: Int,
                 blue: Int) {
        self.x = x
        self.y = y
        self.red = red
        self.green = green
        self.blue = blue
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.display.rawValue }

    public var subType: UInt8? { return BlockType.led.subTypeCode }

    public var commandID: UInt8? { return 0x02 }

    public var payload: [UInt8]? {
        let finalY = y<1 ? 1 : y
        let num = UInt8((finalY-1)*8 + x)
        var datum: [UInt8] = [num]
        datum.append(contentsOf: NeuronDataEncoder.encodeValue(red, type: .SHORT))
        datum.append(contentsOf: NeuronDataEncoder.encodeValue(green, type: .SHORT))
        datum.append(contentsOf: NeuronDataEncoder.encodeValue(blue, type: .SHORT))
        return datum
    }
}

public struct LEDMatrixCommand: NeuronCommand {
    private var amount: Int
    private var colors: [Int]
    public init (amount: Int,
                 colors: [Int], displayMode: Int) {
        self.amount = amount
        self.colors = colors
        self.displayMode = displayMode
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.display.rawValue }

    public var subType: UInt8? { return BlockType.led.subTypeCode }

    public var commandID: UInt8? { return 0x03 }

    private var displayMode: Int = 0

    public var payload: [UInt8]? {

        var datum: [UInt8] = []
        datum.append(UInt8(displayMode))
        datum.append(UInt8(amount))
        for color in colors {
            datum.append(UInt8(color))
        }
        return datum
    }
}

public enum LEDStyle: UInt8 {
    case light = 0x00
    case marquee = 0x01 //使用协议上的滚动实现跑马灯
    case breathing = 0x04
}

public enum LEDColor: Int {
    case black = 0
    case red = 1
    case orange = 2
    case yellow = 3
    case green = 4
    case cyan = 5
    case blue = 6
    case purple = 7
    case white = 8

    init(intValue: Int) {
        self.init(rawValue: intValue)!
    }
}

public struct LEDBandCommand: NeuronCommand {
    private var amount: Int
    private var colors: [LEDColor]
    private var animateMode: LEDStyle = .light
    private var animateSpeed: Int = 1
    public init (amount: Int,
                 colors: [LEDColor], animateMode: LEDStyle, animateSpeed: Int) {
        self.amount = amount
        self.colors = colors
        self.animateMode = animateMode
        if animateSpeed < 0 {
            self.animateSpeed = 0
        } else if animateSpeed > 8 {
            self.animateSpeed = 8
        } else {
            self.animateSpeed = animateSpeed
        }
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.display.rawValue }

    public var subType: UInt8? { return BlockType.ledBand.subTypeCode }

    public var commandID: UInt8? { return 0x02 }

    public var payload: [UInt8]? {
        var datum: [UInt8] = []
        datum.append(animateMode.rawValue)
        datum.append(UInt8(animateSpeed))
        datum.append(UInt8(amount))

        for color in colors {
            datum.append(UInt8(color.rawValue))
        }
        return datum
    }
}

public struct GetKnobCommand: NeuronCommand {
    public init () {
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.control.rawValue  }

    public var subType: UInt8? { return BlockType.knob.subTypeCode }

    public var commandID: UInt8? { return 0x01 }
}

public struct GetLightCommand: NeuronCommand {
    public init () {
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.sensor.rawValue  }

    public var subType: UInt8? { return BlockType.light.subTypeCode }

    public var commandID: UInt8? { return 0x01 }
}

public struct GetTemperatureCommand: NeuronCommand {
    public init () {
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.sensor.rawValue  }

    public var subType: UInt8? { return BlockType.temperature.subTypeCode }

    public var commandID: UInt8? { return 0x01 }
}

public struct GetFunnyTouchCommand: NeuronCommand {
    public init () {
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.control.rawValue  }

    public var subType: UInt8? { return BlockType.funnyTouch.subTypeCode }

    public var commandID: UInt8? { return 0x01 }
}

public struct GetDistanceCommand: NeuronCommand {
    public init () {
    }

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return NeuronTypeCode.sensor.rawValue  }

    public var subType: UInt8? { return BlockType.distance.subTypeCode }

    public var commandID: UInt8? { return 0x01 }
}
